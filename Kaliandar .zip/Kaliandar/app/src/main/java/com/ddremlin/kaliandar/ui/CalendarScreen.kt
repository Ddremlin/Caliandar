package com.ddremlin.kaliandar.ui

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ddremlin.kaliandar.R
import com.ddremlin.kaliandar.data.Event
import com.ddremlin.kaliandar.data.EventColors
import com.ddremlin.kaliandar.data.Repeat
import com.ddremlin.kaliandar.data.endTime
import com.ddremlin.kaliandar.data.on
import com.ddremlin.kaliandar.data.repeatType
import com.ddremlin.kaliandar.data.startTime
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.format.TextStyle
import java.time.temporal.WeekFields
import java.util.Locale

private const val PAGE_COUNT = 2401
private const val START_PAGE = 1200

private fun String.capitalized(locale: Locale) = replaceFirstChar { it.titlecase(locale) }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(vm: CalendarViewModel) {
    val events by vm.events.collectAsStateWithLifecycle()
    val locale = LocalConfiguration.current.locales[0]
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showLanguage by remember { mutableStateOf(false) }
    val baseMonth = remember { YearMonth.now() }
    val pagerState = rememberPagerState(initialPage = START_PAGE) { PAGE_COUNT }

    fun pageOf(month: YearMonth) =
        (START_PAGE + (month.year - baseMonth.year) * 12 + (month.monthValue - baseMonth.monthValue))
            .coerceIn(0, PAGE_COUNT - 1)

    fun monthOf(page: Int): YearMonth = baseMonth.plusMonths((page - START_PAGE).toLong())

    // When the user swipes to another month, move the selection into it
    LaunchedEffect(pagerState.settledPage) {
        val m = monthOf(pagerState.settledPage)
        if (YearMonth.from(vm.selectedDate) != m) {
            val today = LocalDate.now()
            vm.selectedDate = if (YearMonth.from(today) == m) today else m.atDay(1)
        }
    }
    // When the selection jumps to another month (Today button, saved event), follow it
    LaunchedEffect(vm.selectedDate) {
        val target = pageOf(YearMonth.from(vm.selectedDate))
        if (target != pagerState.settledPage) {
            if (tab == 0) pagerState.animateScrollToPage(target) else pagerState.scrollToPage(target)
        }
    }

    var showAssistant by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val shownMonth = monthOf(pagerState.currentPage)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (tab == 0) {
                        MonthYearTitle(
                            month = shownMonth,
                            locale = locale,
                            years = (baseMonth.year - 50)..(baseMonth.year + 50),
                            onPick = { ym -> scope.launch { pagerState.scrollToPage(pageOf(ym)) } },
                        )
                    } else {
                        Text(stringResource(R.string.app_name))
                    }
                },
                actions = {
                    IconButton(onClick = { vm.selectedDate = LocalDate.now() }) {
                        TodayIcon(stringResource(R.string.today))
                    }
                    IconButton(onClick = { showLanguage = true }) {
                        Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.settings))
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.DateRange, null) },
                    label = { Text(stringResource(R.string.tab_month)) },
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.AutoMirrored.Filled.List, null) },
                    label = { Text(stringResource(R.string.tab_agenda)) },
                )
            }
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Small: add event manually
                SmallFloatingActionButton(
                    onClick = { vm.newEvent() },
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                ) {
                    Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.new_event))
                }
                // Main: voice assistant
                FloatingActionButton(onClick = { showAssistant = true }) {
                    Icon(
                        painterResource(R.drawable.ic_mic),
                        contentDescription = stringResource(R.string.assistant_title),
                        modifier = Modifier.size(28.dp),
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (tab == 0) {
                MonthTab(pagerState, ::monthOf, events, vm.selectedDate, locale,
                    onSelect = { vm.selectedDate = it }, onEdit = vm::edit)
            } else {
                AgendaTab(events, locale, onEdit = vm::edit)
            }
        }
    }

    if (showAssistant) {
        VoiceAssistant(
            onSave = {
                showAssistant = false
                vm.save(it)
            },
            onEdit = {
                showAssistant = false
                vm.edit(it)
            },
            onClose = { showAssistant = false },
        )
    }

    vm.editing?.let { event ->
        EventEditor(
            initial = event,
            onSave = vm::save,
            onDelete = vm::delete,
            onClose = vm::closeEditor,
        )
    }

    if (showLanguage) LanguageDialog(onDismiss = { showLanguage = false })
}

@Composable
private fun MonthTab(
    pagerState: PagerState,
    monthOf: (Int) -> YearMonth,
    events: List<Event>,
    selected: LocalDate,
    locale: Locale,
    onSelect: (LocalDate) -> Unit,
    onEdit: (Event) -> Unit,
) {
    val firstDow = remember(locale) { WeekFields.of(locale).firstDayOfWeek }
    Column(Modifier.fillMaxSize()) {
        WeekdayHeader(firstDow, locale)
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxWidth()) { page ->
            MonthGrid(monthOf(page), events, selected, firstDow, onSelect)
        }
        HorizontalDivider()
        val dayEvents = remember(events, selected) { events.on(selected) }
        LazyColumn(Modifier.weight(1f)) {
            item {
                Text(
                    DateTimeFormatter.ofPattern("EEEE, d MMMM", locale).format(selected).capitalized(locale),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
                )
            }
            if (dayEvents.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.no_events),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }
            items(dayEvents, key = { it.id }) { EventRow(it, locale) { onEdit(it) } }
        }
    }
}

@Composable
private fun WeekdayHeader(firstDow: DayOfWeek, locale: Locale) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        repeat(7) { i ->
            val dow = firstDow.plus(i.toLong())
            val weekend = dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY
            Text(
                dow.getDisplayName(TextStyle.SHORT_STANDALONE, locale).capitalized(locale),
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                style = MaterialTheme.typography.labelMedium,
                color = if (weekend) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun MonthGrid(
    month: YearMonth,
    events: List<Event>,
    selected: LocalDate,
    firstDow: DayOfWeek,
    onSelect: (LocalDate) -> Unit,
) {
    val first = month.atDay(1)
    val offset = (first.dayOfWeek.value - firstDow.value + 7) % 7
    val gridStart = first.minusDays(offset.toLong())
    val today = LocalDate.now()
    // Always 6 rows so the pager height stays constant
    val perDay = remember(events, month, firstDow) {
        (0 until 42).associate { i ->
            val d = gridStart.plusDays(i.toLong())
            d to events.on(d)
        }
    }
    Column(Modifier.fillMaxWidth()) {
        repeat(6) { w ->
            Row(Modifier.fillMaxWidth()) {
                repeat(7) { d ->
                    val day = gridStart.plusDays((w * 7 + d).toLong())
                    DayCell(
                        day = day,
                        inMonth = YearMonth.from(day) == month,
                        isToday = day == today,
                        isSelected = day == selected,
                        events = perDay[day].orEmpty(),
                        modifier = Modifier.weight(1f),
                        onClick = { onSelect(day) },
                    )
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    day: LocalDate,
    inMonth: Boolean,
    isToday: Boolean,
    isSelected: Boolean,
    events: List<Event>,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.height(52.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        val bg = when {
            isSelected -> cs.primary
            else -> Color.Transparent
        }
        val fg = when {
            isSelected -> cs.onPrimary
            isToday -> cs.primary
            !inMonth -> cs.onSurface.copy(alpha = 0.35f)
            else -> cs.onSurface
        }
        Box(
            Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(bg)
                .then(if (isToday && !isSelected) Modifier.border(1.5.dp, cs.primary, CircleShape) else Modifier),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                day.dayOfMonth.toString(),
                color = fg,
                fontWeight = if (isToday || isSelected) FontWeight.Bold else FontWeight.Normal,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        Row(Modifier.height(8.dp).padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            events.take(3).forEach {
                Box(
                    Modifier.size(5.dp).clip(CircleShape)
                        .background(eventColor(it).copy(alpha = if (inMonth) 1f else 0.4f))
                )
            }
        }
    }
}

fun eventColor(e: Event) = Color(EventColors.getOrElse(e.color) { EventColors[0] })

@Composable
fun EventRow(event: Event, locale: Locale, onClick: () -> Unit) {
    val timeFmt = remember(locale) { DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(locale) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.width(4.dp).height(40.dp).clip(RoundedCornerShape(2.dp)).background(eventColor(event))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                event.title.ifBlank { stringResource(R.string.no_title) },
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                if (event.allDay) stringResource(R.string.all_day)
                else "${event.startTime.format(timeFmt)} – ${event.endTime.format(timeFmt)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (event.description.isNotBlank()) {
                Text(
                    event.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        val iconTint = MaterialTheme.colorScheme.onSurfaceVariant
        if (event.repeatType != Repeat.NONE) {
            Icon(Icons.Filled.Refresh, null, Modifier.size(16.dp), tint = iconTint)
        }
        if (event.reminderMinutes >= 0) {
            Icon(Icons.Filled.Notifications, null, Modifier.padding(start = 4.dp).size(16.dp), tint = iconTint)
        }
    }
}

@Composable
private fun AgendaTab(events: List<Event>, locale: Locale, onEdit: (Event) -> Unit) {
    val today = LocalDate.now()
    val days = remember(events, today) {
        (0L until 120L).map { today.plusDays(it) }
            .mapNotNull { d -> events.on(d).takeIf { it.isNotEmpty() }?.let { d to it } }
    }
    if (days.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(stringResource(R.string.no_events), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    val fmt = remember(locale) { DateTimeFormatter.ofPattern("EEEE, d MMMM", locale) }
    LazyColumn(Modifier.fillMaxSize()) {
        days.forEach { (day, list) ->
            item(key = "h$day") {
                Text(
                    (if (day == today) stringResource(R.string.today) + " · " else "") +
                        fmt.format(day).capitalized(locale),
                    style = MaterialTheme.typography.titleSmall,
                    color = if (day == today) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 2.dp),
                )
            }
            items(list, key = { "${day}_${it.id}" }) { EventRow(it, locale) { onEdit(it) } }
        }
    }
}

@Composable
private fun LanguageDialog(onDismiss: () -> Unit) {
    val options = listOf(
        "" to stringResource(R.string.lang_system),
        "pl" to "Polski",
        "en" to "English",
        "ru" to "Русский",
        "be" to "Беларуская",
        "uk" to "Українська",
    )
    val current = AppCompatDelegate.getApplicationLocales().toLanguageTags()
        .substringBefore(',').substringBefore('-')
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.settings)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    stringResource(R.string.language),
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(bottom = 4.dp),
                )
                options.forEach { (tag, name) ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable {
                            onDismiss()
                            AppCompatDelegate.setApplicationLocales(
                                if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList()
                                else LocaleListCompat.forLanguageTags(tag)
                            )
                        },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = current == tag, onClick = null, modifier = Modifier.padding(12.dp))
                        Text(name)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
                OfflineModelSection()
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}

@Composable
private fun MonthYearTitle(
    month: YearMonth,
    locale: Locale,
    years: IntRange,
    onPick: (YearMonth) -> Unit,
) {
    var monthOpen by remember { mutableStateOf(false) }
    var yearOpen by remember { mutableStateOf(false) }
    val monthFmt = remember(locale) { DateTimeFormatter.ofPattern("LLLL", locale) }
    fun monthName(m: Int) = monthFmt.format(YearMonth.of(2000, m)).capitalized(locale)
    val pad = PaddingValues(horizontal = 6.dp)

    Row(verticalAlignment = Alignment.CenterVertically) {
        Box {
            TextButton(onClick = { monthOpen = true }, contentPadding = pad) {
                Text(
                    monthName(month.monthValue),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                )
                Icon(Icons.Filled.ArrowDropDown, contentDescription = stringResource(R.string.month))
            }
            DropdownMenu(expanded = monthOpen, onDismissRequest = { monthOpen = false }) {
                (1..12).forEach { m ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                monthName(m),
                                fontWeight = if (m == month.monthValue) FontWeight.Bold else FontWeight.Normal,
                                color = if (m == month.monthValue) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurface,
                            )
                        },
                        onClick = {
                            monthOpen = false
                            onPick(YearMonth.of(month.year, m))
                        },
                    )
                }
            }
        }
        Box {
            TextButton(onClick = { yearOpen = true }, contentPadding = pad) {
                Text(
                    month.year.toString(),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Icon(Icons.Filled.ArrowDropDown, contentDescription = stringResource(R.string.year))
            }
            val scroll = rememberScrollState()
            val itemPx = with(LocalDensity.current) { 48.dp.roundToPx() }
            DropdownMenu(
                expanded = yearOpen,
                onDismissRequest = { yearOpen = false },
                scrollState = scroll,
                modifier = Modifier.heightIn(max = 360.dp),
            ) {
                years.forEach { y ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                y.toString(),
                                fontWeight = if (y == month.year) FontWeight.Bold else FontWeight.Normal,
                                color = if (y == month.year) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurface,
                            )
                        },
                        onClick = {
                            yearOpen = false
                            onPick(YearMonth.of(y, month.monthValue))
                        },
                    )
                }
            }
            // Open the list at the current year
            LaunchedEffect(yearOpen) {
                if (yearOpen) {
                    snapshotFlow { scroll.maxValue }.first { it > 0 && it != Int.MAX_VALUE }
                    scroll.scrollTo(((month.year - years.first - 3).coerceAtLeast(0)) * itemPx)
                }
            }
        }
    }
}

/** Small calendar-page icon with today's day number. */
@Composable
private fun TodayIcon(description: String) {
    Box(
        Modifier
            .size(26.dp)
            .border(2.dp, MaterialTheme.colorScheme.onSurfaceVariant, RoundedCornerShape(5.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            LocalDate.now().dayOfMonth.toString(),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.semantics { contentDescription = description },
        )
    }
}
