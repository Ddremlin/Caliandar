package com.ddremlin.kaliandar.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.ddremlin.kaliandar.R
import com.ddremlin.kaliandar.ui.AssistantActivity
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/** Settings for the floating mic (in the app and over other apps). */
object OverlayPrefs {
    private fun prefs(c: Context) = c.getSharedPreferences("overlay", Context.MODE_PRIVATE)

    fun isEnabled(c: Context) = prefs(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, value: Boolean) = prefs(c).edit().putBoolean("enabled", value).apply()

    /** Bubble position over other apps, in pixels. */
    fun bubblePos(c: Context): Pair<Int, Int>? =
        if (prefs(c).contains("bx")) prefs(c).getInt("bx", 0) to prefs(c).getInt("by", 0) else null
    fun setBubblePos(c: Context, x: Int, y: Int) = prefs(c).edit().putInt("bx", x).putInt("by", y).apply()

    /** In-app button position, as fractions of the free area (0..1). */
    fun appPos(c: Context): Pair<Float, Float>? =
        if (prefs(c).contains("ax")) prefs(c).getFloat("ax", 1f) to prefs(c).getFloat("ay", 1f) else null
    fun setAppPos(c: Context, x: Float, y: Float) = prefs(c).edit().putFloat("ax", x).putFloat("ay", y).apply()

    fun canDraw(c: Context) = Settings.canDrawOverlays(c)
}

/**
 * Foreground service that shows a draggable mic bubble over other apps
 * while Kaliandar itself is in the background. Tap -> voice assistant.
 */
class FloatingMicService : Service() {

    companion object {
        /** True while one of our screens is visible: the bubble hides itself then. */
        val appVisible = MutableStateFlow(false)

        private const val ACTION_STOP = "com.ddremlin.kaliandar.STOP_BUBBLE"
        private const val CHANNEL = "bubble"
        private const val NOTIFICATION_ID = 7001

        fun start(context: Context) {
            if (!OverlayPrefs.canDraw(context)) return
            ContextCompat.startForegroundService(context, Intent(context, FloatingMicService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingMicService::class.java))
        }

        /** Starts the bubble if the user turned it on. */
        fun startIfEnabled(context: Context) {
            if (OverlayPrefs.isEnabled(context) && OverlayPrefs.canDraw(context)) runCatching { start(context) }
        }
    }

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private val scope = MainScope()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WindowManager::class.java)
        if (OverlayPrefs.canDraw(this)) addBubble() else stopSelf()
        scope.launch {
            appVisible.collect { visible -> bubble?.visibility = if (visible) View.GONE else View.VISIBLE }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            OverlayPrefs.setEnabled(this, false)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.overlay_channel), NotificationManager.IMPORTANCE_MIN)
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingMicService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val open = PendingIntent.getActivity(
            this, 2,
            Intent(this, AssistantActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(getString(R.string.overlay_notification))
            .setContentIntent(open)
            .addAction(0, getString(R.string.overlay_hide), stop)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        val density = resources.displayMetrics.density
        val size = (60 * density).roundToInt()

        val view = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1E5BB8"))
                setStroke((2 * density).roundToInt(), Color.WHITE)
            }
            elevation = 8 * density
            alpha = 0.92f
            contentDescription = getString(R.string.assistant_title)
            addView(
                ImageView(context).apply {
                    setImageResource(R.drawable.ic_mic)
                    setColorFilter(Color.WHITE)
                },
                FrameLayout.LayoutParams((28 * density).roundToInt(), (28 * density).roundToInt(), Gravity.CENTER),
            )
        }

        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val (x0, y0) = OverlayPrefs.bubblePos(this) ?: ((screenW - size - 16 * density).roundToInt() to (screenH * 0.6f).roundToInt())

        params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = x0.coerceIn(0, screenW - size)
            y = y0.coerceIn(0, screenH - size)
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        view.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = e.rawX
                        touchY = e.rawY
                        moved = false
                        v.alpha = 1f
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).roundToInt()
                        val dy = (e.rawY - touchY).roundToInt()
                        if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                        if (moved) {
                            val w = resources.displayMetrics.widthPixels
                            val h = resources.displayMetrics.heightPixels
                            params.x = (startX + dx).coerceIn(0, w - size)
                            params.y = (startY + dy).coerceIn(0, h - size)
                            wm.updateViewLayout(v, params)
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.alpha = 0.92f
                        if (moved) {
                            // stick to the nearest screen edge
                            val w = resources.displayMetrics.widthPixels
                            val margin = (8 * density).roundToInt()
                            params.x = if (params.x + size / 2 < w / 2) margin else w - size - margin
                            wm.updateViewLayout(v, params)
                            OverlayPrefs.setBubblePos(this@FloatingMicService, params.x, params.y)
                        } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                            v.performClick()
                            openAssistant()
                        }
                    }
                }
                return true
            }
        })

        try {
            wm.addView(view, params)
            bubble = view
            if (appVisible.value) view.visibility = View.GONE
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun openAssistant() {
        startActivity(
            Intent(this, AssistantActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }
}
