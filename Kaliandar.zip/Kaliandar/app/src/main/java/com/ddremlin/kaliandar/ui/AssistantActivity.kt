package com.ddremlin.kaliandar.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ddremlin.kaliandar.data.AppDatabase
import com.ddremlin.kaliandar.data.Event
import com.ddremlin.kaliandar.overlay.FloatingMicService
import com.ddremlin.kaliandar.reminders.ReminderScheduler
import com.ddremlin.kaliandar.ui.theme.KaliandarTheme
import kotlinx.coroutines.launch

/**
 * Voice assistant opened from the floating bubble, on top of whatever app is in front.
 * Saves the event and closes, so the user returns to where they were.
 */
class AssistantActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KaliandarTheme {
                VoiceAssistant(
                    onSave = { event ->
                        lifecycleScope.launch {
                            val id = AppDatabase.get(applicationContext).events().save(event)
                            ReminderScheduler.schedule(applicationContext, event.copy(id = id))
                            finish()
                        }
                    },
                    onEdit = { event ->
                        startActivity(
                            EventExtras.put(Intent(this, MainActivity::class.java), event)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        )
                        finish()
                    },
                    onClose = { finish() },
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        FloatingMicService.appVisible.value = true
    }

    override fun onStop() {
        super.onStop()
        FloatingMicService.appVisible.value = false
    }
}

/** Passes an unsaved event between activities. */
object EventExtras {
    private const val KEY = "draft_event"

    fun put(intent: Intent, e: Event): Intent = intent
        .putExtra(KEY, true)
        .putExtra("$KEY.title", e.title)
        .putExtra("$KEY.description", e.description)
        .putExtra("$KEY.date", e.date)
        .putExtra("$KEY.allDay", e.allDay)
        .putExtra("$KEY.start", e.startMinute)
        .putExtra("$KEY.end", e.endMinute)
        .putExtra("$KEY.color", e.color)
        .putExtra("$KEY.reminder", e.reminderMinutes)
        .putExtra("$KEY.repeat", e.repeat)

    fun take(intent: Intent?): Event? {
        if (intent?.getBooleanExtra(KEY, false) != true) return null
        intent.removeExtra(KEY)
        return Event(
            title = intent.getStringExtra("$KEY.title").orEmpty(),
            description = intent.getStringExtra("$KEY.description").orEmpty(),
            date = intent.getLongExtra("$KEY.date", java.time.LocalDate.now().toEpochDay()),
            allDay = intent.getBooleanExtra("$KEY.allDay", false),
            startMinute = intent.getIntExtra("$KEY.start", 9 * 60),
            endMinute = intent.getIntExtra("$KEY.end", 10 * 60),
            color = intent.getIntExtra("$KEY.color", 0),
            reminderMinutes = intent.getIntExtra("$KEY.reminder", 15),
            repeat = intent.getStringExtra("$KEY.repeat") ?: "NONE",
        )
    }
}
