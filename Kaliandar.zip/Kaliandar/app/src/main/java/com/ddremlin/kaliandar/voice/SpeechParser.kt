package com.ddremlin.kaliandar.voice

import com.ddremlin.kaliandar.data.Repeat
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

/** What could be understood from a spoken phrase. Null = not mentioned. */
data class ParsedEvent(
    val title: String = "",
    val date: LocalDate? = null,
    val allDay: Boolean = false,
    val startMinute: Int? = null,
    val endMinute: Int? = null,
    /** Minutes before start; -1 = explicitly no reminder */
    val reminder: Int? = null,
    val repeat: Repeat? = null,
)

/**
 * Rule-based parser for spoken events in pl/en/ru/be/uk, e.g.
 * "завтра в 15:30 встреча с врачом, напомни за час" ->
 * date = tomorrow, start = 15:30, reminder = 60, title = "Встреча с врачом".
 * Works offline and understands numbers both as digits and as words.
 */
class SpeechParser(lang: String, private val today: LocalDate = LocalDate.now()) {
    private val lx = Lexicon.of(lang)
    private val numberStems = lx.numbers.map { norm(it.first) to it.second }.sortedByDescending { it.first.length }

    private var tokens: List<String> = emptyList()
    private var original: List<String> = emptyList()
    private var used = BooleanArray(0)

    fun parse(text: String): ParsedEvent {
        load(text)
        val reminder = findReminder(answerMode = false)
        val repeat = findRepeat()
        var date = findDate()
        val time = findTime()
        // "каждый понедельник" -> weekly on Monday
        val weeklyByDay = repeat == null && everyBeforeWeekday
        if (date == null && repeat != null && repeat != Repeat.NONE) date = today
        return ParsedEvent(
            title = title(),
            date = date,
            allDay = time?.allDay ?: false,
            startMinute = time?.start,
            endMinute = time?.end,
            reminder = reminder,
            repeat = if (weeklyByDay) Repeat.WEEKLY else repeat,
        )
    }

    /** Answer to "when to remind?" — understands bare "15 минут", "нет", "за час". */
    fun parseReminderAnswer(text: String): Int? {
        load(text)
        return findReminder(answerMode = true)
    }

    /** Short answer meaning "skip / no". */
    fun isSkip(text: String): Boolean {
        load(text)
        return tokens.isNotEmpty() && tokens.size <= 3 && tokens.any { t -> lx.skip.any { m(t, it) } }
    }

    // ---------------------------------------------------------------- tokens

    private fun load(text: String) {
        val raw = text.split(Regex("\\s+")).map { it.trim('.', ',', '!', '?', ';', '"', '«', '»', '(', ')', '—', '–') }
            .filter { it.isNotEmpty() && it != "-" }
        original = raw
        tokens = raw.map { norm(it) }
        used = BooleanArray(tokens.size)
        everyBeforeWeekday = false
    }

    private fun norm(s: String): String {
        var t = s.lowercase().replace('ё', 'е').replace("'", "").replace("’", "").replace("ʼ", "").replace("`", "")
        // Belarusian/Ukrainian text sometimes comes with a Latin "i"
        if (t.any { it in 'а'..'я' || it == 'ў' || it == 'і' || it == 'ї' || it == 'є' }) t = t.replace('i', 'і')
        return t
    }

    private fun m(token: String, stem: String): Boolean =
        if (stem.startsWith("=")) token == norm(stem.drop(1)) else token.startsWith(norm(stem))

    private fun isAny(i: Int, stems: List<String>) =
        i in tokens.indices && !used[i] && stems.any { m(tokens[i], it) }

    private fun phraseAt(i: Int, phrase: List<String>): Boolean {
        if (i < 0 || i + phrase.size > tokens.size) return false
        return phrase.indices.all { k -> !used[i + k] && m(tokens[i + k], phrase[k]) }
    }

    private fun findPhrase(phrases: List<List<String>>, from: Int = 0, to: Int = tokens.size): Pair<Int, Int>? {
        for (i in from until to) for (p in phrases) if (phraseAt(i, p)) return i to p.size
        return null
    }

    private fun consume(i: Int, len: Int, preps: List<String> = emptyList()) {
        for (k in i until (i + len).coerceAtMost(tokens.size)) used[k] = true
        if (preps.isNotEmpty() && isAny(i - 1, preps)) used[i - 1] = true
    }

    /** Number at i (digits or words, "двадцать пять" = 25). Returns value and token count. */
    private fun numberAt(i: Int): Pair<Int, Int>? {
        if (i !in tokens.indices || used[i]) return null
        val t = tokens[i]
        Regex("^(\\d{1,4})(?:-?[a-zа-яіўїєąćęłńóśźż.]*)$").find(t)?.let { return it.groupValues[1].toInt() to 1 }
        val v = wordNumber(t) ?: return null
        if (v in listOf(20, 30, 40, 50)) {
            val next = tokens.getOrNull(i + 1)?.takeIf { !used[i + 1] }?.let { wordNumber(it) }
            if (next != null && next in 1..9) return v + next to 2
        }
        return v to 1
    }

    private fun wordNumber(t: String): Int? = numberStems.firstOrNull { (stem, _) ->
        if (stem.startsWith("=")) t == stem.drop(1) else t.startsWith(stem)
    }?.second

    // ---------------------------------------------------------------- reminder

    private fun unitMinutes(i: Int): Int? = when {
        isAny(i, lx.minuteUnit) -> 1
        isAny(i, lx.hourUnit) -> 60
        isAny(i, lx.dayUnit) -> 1440
        isAny(i, lx.weekUnit) -> 10080
        else -> null
    }

    /** "15 минут", "2 часа", "час", "полчаса" starting at i -> minutes and length */
    private fun durationAt(i: Int): Pair<Int, Int>? {
        for (p in lx.halfHour) if (phraseAt(i, p)) return 30 to p.size
        numberAt(i)?.let { (n, len) ->
            unitMinutes(i + len)?.let { return n * it to len + 1 }
        }
        // unit alone: "за час", "an hour", "a day"
        var j = i
        if (tokens.getOrNull(j) in listOf("an", "a", "one")) j++
        unitMinutes(j)?.let { u -> if (u != 1) return u to j - i + 1 }
        return null
    }

    private fun findReminder(answerMode: Boolean): Int? {
        val trigger = tokens.indices.firstOrNull { isAny(it, lx.remind) }
        val from = if (trigger != null) {
            used[trigger] = true
            trigger + 1
        } else 0
        val searchAll = answerMode || trigger != null
        // "без напоминания", "no reminder", "nie przypominaj"
        if (trigger != null && isAny(trigger - 1, lx.noReminder)) {
            used[trigger - 1] = true
            return -1
        }

        if (searchAll) {
            val to = tokens.size
            findPhrase(lx.atStart, from, to)?.let { (i, len) -> consume(i, len); return 0 }
            // "without reminder" / "no"
            val noIdx = (from until to).firstOrNull { isAny(it, lx.noReminder) }
            if (noIdx != null && (answerMode || noIdx <= from + 1)) {
                val hasDuration = (from until to).any { durationAt(it) != null }
                if (!hasDuration) {
                    used[noIdx] = true
                    return -1
                }
            }
        }
        // "за 15 минут"
        for (i in from until tokens.size) {
            if (isAny(i, lx.remindBefore)) durationAt(i + 1)?.let { (min, len) ->
                consume(i, len + 1)
                return min
            }
        }
        // "15 minutes before"
        for (i in from until tokens.size) {
            durationAt(i)?.let { (min, len) ->
                if (isAny(i + len, lx.remindAfter)) {
                    consume(i, len + 1)
                    return min
                }
                if (searchAll && (answerMode || i <= from + 3)) {
                    consume(i, len)
                    return min
                }
            }
        }
        if (searchAll && answerMode) {
            // just a number: "15" -> 15 minutes
            for (i in from until tokens.size) numberAt(i)?.let { (n, len) -> consume(i, len); return n }
        }
        return null
    }

    // ---------------------------------------------------------------- repeat

    private var everyBeforeWeekday = false

    private fun findRepeat(): Repeat? {
        val table = listOf(Repeat.DAILY to lx.daily, Repeat.WEEKLY to lx.weekly, Repeat.MONTHLY to lx.monthly, Repeat.YEARLY to lx.yearly)
        for ((repeat, phrases) in table) findPhrase(phrases)?.let { (i, len) ->
            consume(i, len)
            return repeat
        }
        return null
    }

    // ---------------------------------------------------------------- date

    private fun findDate(): LocalDate? {
        findPhrase(lx.afterTomorrow)?.let { (i, len) -> consume(i, len, lx.datePreps); return today.plusDays(2) }
        tokens.indices.firstOrNull { isAny(it, lx.tomorrow) }?.let { consume(it, 1, lx.datePreps); return today.plusDays(1) }
        tokens.indices.firstOrNull { isAny(it, lx.today) }?.let { consume(it, 1, lx.datePreps); return today }

        // "через 3 дня", "in 2 weeks"
        for (i in tokens.indices) if (isAny(i, lx.inPreps)) {
            numberAt(i + 1)?.let { (n, len) ->
                when {
                    isAny(i + 1 + len, lx.dayUnit) -> { consume(i, len + 2); return today.plusDays(n.toLong()) }
                    isAny(i + 1 + len, lx.weekUnit) -> { consume(i, len + 2); return today.plusWeeks(n.toLong()) }
                }
            }
            if (isAny(i + 1, lx.weekUnit)) { consume(i, 2); return today.plusWeeks(1) }
        }

        // 25.11 / 25.11.2026 / 25/11
        for (i in tokens.indices) {
            if (used[i]) continue
            val mt = Regex("^(\\d{1,2})[./](\\d{1,2})(?:[./](\\d{2,4}))?$").find(tokens[i]) ?: continue
            val d = mt.groupValues[1].toInt()
            val mo = mt.groupValues[2].toInt()
            val y = mt.groupValues[3].takeIf { it.isNotEmpty() }?.toInt()?.let { if (it < 100) 2000 + it else it }
            makeDate(d, mo, y)?.let { consume(i, 1, lx.datePreps); return it }
        }

        // "25 ноября", "November 25", "the 3rd of May"
        for (i in tokens.indices) {
            val month = monthAt(i) ?: continue
            // number before the month (optionally "of")
            var j = i - 1
            if (tokens.getOrNull(j) == "of") j--
            for (len in 2 downTo 1) {
                val start = j - len + 1
                val n = numberAt(start)
                if (n != null && n.second == len && n.first in 1..31) {
                    val (year, yLen) = yearAt(i + 1)
                    makeDate(n.first, month, year)?.let { consume(start, i - start + 1 + yLen, lx.datePreps); return it }
                }
            }
            // number after the month
            numberAt(i + 1)?.let { (n, len) ->
                if (n in 1..31) {
                    val (year, yLen) = yearAt(i + 1 + len)
                    makeDate(n, month, year)?.let { consume(i, 1 + len + yLen, lx.datePreps); return it }
                }
            }
        }

        // weekday: "в пятницу", "next Monday", "каждый понедельник"
        for (i in tokens.indices) {
            val dow = lx.weekdays.indexOfFirst { stems -> isAny(i, stems) }
            if (dow < 0) continue
            if (isAny(i - 1, lx.every)) {
                everyBeforeWeekday = true
                used[i - 1] = true
            }
            consume(i, 1, lx.datePreps)
            // "next"/"следующий" right before the weekday
            if (i > 0 && !used[i - 1] && tokens[i - 1].let {
                    it.startsWith("следующ") || it.startsWith("наступн") || it.startsWith("next") ||
                        it.startsWith("przysz") || it.startsWith("наступ")
                }
            ) {
                used[i - 1] = true
                if (i > 1 && isAny(i - 2, lx.datePreps)) used[i - 2] = true
            }
            val target = DayOfWeek.of(dow + 1)
            return if (today.dayOfWeek == target) today.plusWeeks(1) else today.with(TemporalAdjusters.next(target))
        }
        return null
    }

    private fun monthAt(i: Int): Int? {
        val idx = lx.months.indexOfFirst { stems -> isAny(i, stems) }
        return if (idx >= 0) idx + 1 else null
    }

    private fun yearAt(i: Int): Pair<Int?, Int> {
        val t = tokens.getOrNull(i) ?: return null to 0
        if (used[i]) return null to 0
        val y = Regex("^(\\d{4})").find(t)?.groupValues?.get(1)?.toInt() ?: return null to 0
        // optional "года"/"roku"/"year"
        val extra = if (tokens.getOrNull(i + 1)?.let { it.startsWith("год") || it.startsWith("рок") || it.startsWith("year") || it.startsWith("гад") } == true) 1 else 0
        return y to 1 + extra
    }

    private fun makeDate(day: Int, month: Int, year: Int?): LocalDate? {
        if (month !in 1..12 || day !in 1..31) return null
        return runCatching {
            if (year != null) return LocalDate.of(year, month, day)
            val d = LocalDate.of(today.year, month, day.coerceAtMost(java.time.YearMonth.of(today.year, month).lengthOfMonth()))
            if (d.isBefore(today)) d.plusYears(1) else d
        }.getOrNull()
    }

    // ---------------------------------------------------------------- time

    private data class TimeResult(val allDay: Boolean, val start: Int?, val end: Int?)

    private fun findTime(): TimeResult? {
        findPhrase(lx.allDay)?.let { (i, len) -> consume(i, len); return TimeResult(true, null, null) }
        val start = timeAt(fromAnywhere = true) ?: return null
        val end = run {
            for (i in tokens.indices) if (isAny(i, lx.endPreps)) {
                val t = timeAtIndex(i + 1, allowBare = true)
                if (t != null) {
                    used[i] = true
                    return@run adjust(t.first, t.second, startMinute = start)
                }
            }
            null
        }
        return TimeResult(false, start, end)
    }

    private fun timeAt(fromAnywhere: Boolean): Int? {
        // 1) "15:30", "3pm", "3:30pm"
        for (i in tokens.indices) {
            if (used[i]) continue
            Regex("^(\\d{1,2})[:.](\\d{2})(am|pm)?$").find(tokens[i])?.let { mt ->
                val h = mt.groupValues[1].toInt()
                val mi = mt.groupValues[2].toInt()
                if (h <= 24 && mi <= 59 && (tokens[i].contains(':') || isAny(i - 1, lx.timePreps))) {
                    consume(i, 1, lx.timePreps)
                    return adjust(toPm(h, mt.groupValues[3]), mi, null, i)
                }
            }
            Regex("^(\\d{1,2})(am|pm)$").find(tokens[i])?.let { mt ->
                consume(i, 1, lx.timePreps)
                return adjust(toPm(mt.groupValues[1].toInt(), mt.groupValues[2]), 0, null, i)
            }
        }
        // 2) noon
        tokens.indices.firstOrNull { isAny(it, lx.noon) }?.let { consume(it, 1, lx.timePreps); return 12 * 60 }
        // 3) "3 часа 30 минут", "o 15 godzinie"
        for (i in tokens.indices) {
            val n = numberAt(i) ?: continue
            if (n.first in 0..24 && isAny(i + n.second, lx.hourUnit)) {
                var len = n.second + 1
                var min = 0
                numberAt(i + len)?.let { (mn, ml) ->
                    if (mn in 0..59) {
                        min = mn
                        len += ml
                        if (isAny(i + len, lx.minuteUnit)) len++
                    }
                }
                consume(i, len, lx.timePreps)
                return adjust(n.first, min, null, i)
            }
            // "в 15 часов" written as hour word before number: "o godzinie 15"
            if (isAny(i - 1, lx.hourUnit) && n.first in 0..24 && isAny(i - 2, lx.timePreps)) {
                consume(i - 1, n.second + 1, lx.timePreps)
                return adjust(n.first, minutesAfter(i + n.second), null, i)
            }
        }
        // 4) "в час дня" (hour word alone = 1)
        if (lx.hourAloneIsOne) for (i in tokens.indices) {
            if (isAny(i, lx.hourUnit) && isAny(i - 1, lx.timePreps) && numberAt(i - 1) == null) {
                consume(i, 1, lx.timePreps)
                return adjust(1, 0, null, i)
            }
        }
        // 5) "в 15", "в 9 30", "o piętnastej", "at 7"
        if (fromAnywhere) for (i in tokens.indices) {
            if (!isAny(i, lx.timePreps)) continue
            val t = timeAtIndex(i + 1, allowBare = true) ?: continue
            used[i] = true
            return adjust(t.first, t.second, null, i + 1)
        }
        return null
    }

    /** Time starting exactly at index i: "15:30", "15", "15 30", "piętnastej trzydzieści". */
    private fun timeAtIndex(i: Int, allowBare: Boolean): Pair<Int, Int>? {
        if (i !in tokens.indices || used[i]) return null
        Regex("^(\\d{1,2})[:.](\\d{2})$").find(tokens[i])?.let {
            used[i] = true
            return it.groupValues[1].toInt() to it.groupValues[2].toInt()
        }
        if (!allowBare) return null
        val (h, len) = numberAt(i) ?: return null
        if (h !in 0..24) return null
        // not a date or a duration
        if (monthAt(i + len) != null || unitMinutes(i + len)?.let { it != 60 } == true) return null
        var end = i + len
        if (isAny(end, lx.hourUnit)) end++
        for (k in i until end) used[k] = true
        return h to minutesAfter(end)
    }

    private fun minutesAfter(i: Int): Int {
        val (mn, ml) = numberAt(i) ?: return 0
        if (mn !in 0..59 || monthAt(i + ml) != null) return 0
        for (k in i until i + ml) used[k] = true
        if (isAny(i + ml, lx.minuteUnit)) used[i + ml] = true
        return mn
    }

    private fun toPm(h: Int, suffix: String) = when {
        suffix == "pm" && h < 12 -> h + 12
        suffix == "am" && h == 12 -> 0
        else -> h
    }

    /** Applies "вечера/утра/pm/am" said near the time. */
    private fun adjust(hour: Int, minute: Int, startMinute: Int? = null, near: Int = -1): Int {
        var h = hour % 24
        val window = if (near >= 0) (near - 2..near + 4) else tokens.indices
        val pmIdx = window.firstOrNull { isAny(it, lx.pm) }
        val amIdx = window.firstOrNull { isAny(it, lx.am) }
        if (pmIdx != null && h < 12) { h += 12; used[pmIdx] = true }
        if (amIdx != null) { if (h == 12) h = 0; used[amIdx] = true }
        var result = h * 60 + minute
        // end time "до 5" after start 15:00 -> 17:00
        if (startMinute != null && result <= startMinute && h < 12) result += 12 * 60
        return result.coerceIn(0, 23 * 60 + 59)
    }

    // ---------------------------------------------------------------- title

    private fun title(): String {
        val left = tokens.indices.filter { !used[it] }.toMutableList()
        fun filler(i: Int) = lx.fillers.any { m(tokens[i], it) } || lx.remind.any { m(tokens[i], it) }
        while (left.isNotEmpty() && filler(left.first())) left.removeAt(0)
        while (left.isNotEmpty() && (filler(left.last()) || lx.timePreps.any { m(tokens[left.last()], it) })) left.removeAt(left.size - 1)
        return left.joinToString(" ") { original[it] }
            .trim(',', ' ')
            .replaceFirstChar { it.uppercaseChar() }
    }
}
