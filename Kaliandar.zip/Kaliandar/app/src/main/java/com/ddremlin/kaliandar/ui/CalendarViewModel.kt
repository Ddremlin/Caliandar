package com.ddremlin.kaliandar.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ddremlin.kaliandar.data.AppDatabase
import com.ddremlin.kaliandar.data.Event
import com.ddremlin.kaliandar.reminders.ReminderScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class CalendarViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).events()

    val events: StateFlow<List<Event>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    var selectedDate by mutableStateOf(LocalDate.now())

    /** Event open in the editor (id == 0 means new), or null when the editor is closed. */
    var editing by mutableStateOf<Event?>(null)
        private set

    fun newEvent(
        date: LocalDate = selectedDate,
        title: String = "",
        description: String = "",
        startMinute: Int? = null,
    ) {
        val base = Event(title = title, description = description, date = date.toEpochDay())
        editing = if (startMinute == null) base else base.copy(
            startMinute = startMinute,
            endMinute = (startMinute + 30).coerceAtMost(23 * 60 + 59),
        )
    }

    fun edit(event: Event) {
        editing = event
    }

    fun closeEditor() {
        editing = null
    }

    fun save(event: Event) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val id = dao.save(event)
            ReminderScheduler.schedule(ctx, event.copy(id = id))
        }
        selectedDate = java.time.LocalDate.ofEpochDay(event.date)
        editing = null
    }

    fun delete(event: Event) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            ReminderScheduler.cancel(ctx, event.id)
            dao.delete(event)
        }
        editing = null
    }
}
