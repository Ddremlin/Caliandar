package com.ddremlin.kaliandar.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.ddremlin.kaliandar.R
import com.ddremlin.kaliandar.voice.VoiceController
import com.ddremlin.kaliandar.voice.VoiceState
import com.ddremlin.kaliandar.voice.OfflineModels
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/**
 * Returns a function that opens the voice input dialog and passes the recognized text to [onResult].
 */
@Composable
fun rememberVoiceInput(onResult: (String) -> Unit): () -> Unit {
    var open by remember { mutableStateOf(false) }
    val callback by rememberUpdatedState(onResult)
    if (open) {
        VoiceDialog(
            onDone = { text ->
                open = false
                if (text.isNotBlank()) callback(text)
            },
            onCancel = { open = false },
        )
    }
    return { open = true }
}

/** Microphone button that dictates text and hands it to [onText]. */
@Composable
fun VoiceButton(onText: (String) -> Unit) {
    val listen = rememberVoiceInput(onText)
    IconButton(onClick = listen) {
        Icon(painterResource(R.drawable.ic_mic), contentDescription = stringResource(R.string.voice_input))
    }
}

@Composable
private fun VoiceDialog(onDone: (String) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current.applicationContext
    val locale = LocalConfiguration.current.locales[0]
    val scope = rememberCoroutineScope()
    val controller = remember { VoiceController(context, locale, scope) }

    DisposableEffect(Unit) { onDispose { controller.release() } }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) controller.start() else controller.state = VoiceState.NoPermission
    }
    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) controller.start() else permission.launch(Manifest.permission.RECORD_AUDIO)
    }
    LaunchedEffect(controller.autoFinished) {
        if (controller.autoFinished) controller.finish(onDone)
    }

    val state = controller.state
    AlertDialog(
        onDismissRequest = onCancel,
        icon = { MicPulse(active = state is VoiceState.Listening) },
        title = {
            Text(
                stringResource(
                    if (state is VoiceState.Listening && state.offline) R.string.voice_listening_offline
                    else R.string.voice_input
                )
            )
        },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(min = 64.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                val text = controller.currentText
                when (state) {
                    VoiceState.Starting, is VoiceState.Listening -> Text(
                        text.ifBlank { stringResource(R.string.voice_prompt) },
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (text.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.onSurface,
                    )
                    VoiceState.LoadingModel -> Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        CircularProgressIndicator(Modifier.size(24.dp))
                        Text(stringResource(R.string.voice_loading_model))
                    }
                    is VoiceState.NeedModel -> {
                        Text(stringResource(R.string.voice_need_model, state.sizeMb))
                        if (locale.language == "be") Text(
                            stringResource(R.string.offline_model_be_note),
                            style = MaterialTheme.typography.bodySmall,
                        )
                        Button(onClick = controller::downloadModel) { Text(stringResource(R.string.voice_download)) }
                    }
                    is VoiceState.Downloading -> {
                        Text(stringResource(R.string.voice_downloading, (state.progress * 100).toInt()))
                        LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                    }
                    VoiceState.DownloadFailed -> {
                        Text(stringResource(R.string.voice_download_failed))
                        Button(onClick = controller::downloadModel) { Text(stringResource(R.string.voice_download)) }
                    }
                    VoiceState.NoPermission -> Text(stringResource(R.string.voice_no_permission))
                    VoiceState.Error -> Text(stringResource(R.string.voice_error))
                }
                if (controller.processing) Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    CircularProgressIndicator(Modifier.size(20.dp))
                    Text(stringResource(R.string.voice_processing), style = MaterialTheme.typography.bodySmall)
                }
                // Text already recognized stays visible even if the engine changed
                if (state !is VoiceState.Listening && state != VoiceState.Starting && text.isNotBlank()) {
                    Text(text, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { controller.finish(onDone) },
                enabled = controller.currentText.isNotBlank() && !controller.processing,
            ) { Text(stringResource(R.string.voice_done)) }
        },
        dismissButton = {
            TextButton(onClick = onCancel) { Text(stringResource(R.string.cancel)) }
        },
    )
}

@Composable
private fun MicPulse(active: Boolean) {
    val transition = rememberInfiniteTransition(label = "mic")
    val pulse by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "pulse",
    )
    Box(
        Modifier
            .size(56.dp)
            .alpha(if (active) pulse else 0.5f)
            .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painterResource(R.drawable.ic_mic),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.size(28.dp),
        )
    }
}

/** Settings block: download / delete the offline model for the current language. */
@Composable
fun OfflineModelSection() {
    val context = LocalContext.current.applicationContext
    val lang = LocalConfiguration.current.locales[0].language
    val model = remember(lang) { OfflineModels.forLanguage(lang) }
    var ready by remember(model) { mutableStateOf(OfflineModels.isReady(context, model)) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var failed by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(stringResource(R.string.offline_model), style = MaterialTheme.typography.titleSmall)
        Text(
            stringResource(R.string.offline_model_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (lang == "be") Text(stringResource(R.string.offline_model_be_note), style = MaterialTheme.typography.bodySmall)
        val p = progress
        when {
            p != null -> {
                Text(stringResource(R.string.voice_downloading, (p * 100).toInt()), style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
            }
            ready -> Text(stringResource(R.string.offline_model_ready), style = MaterialTheme.typography.bodyMedium)
            failed -> Text(stringResource(R.string.voice_download_failed), style = MaterialTheme.typography.bodyMedium)
            else -> Text(stringResource(R.string.offline_model_missing, model.sizeMb), style = MaterialTheme.typography.bodyMedium)
        }
        if (p == null) {
            if (ready) {
                TextButton(onClick = {
                    OfflineModels.delete(context, model)
                    ready = false
                }) { Text(stringResource(R.string.delete)) }
            } else {
                Button(onClick = {
                    failed = false
                    progress = 0f
                    scope.launch {
                        try {
                            OfflineModels.download(context, model) { progress = it }
                            ready = true
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            failed = true
                        } finally {
                            progress = null
                        }
                    }
                }) { Text(stringResource(R.string.voice_download)) }
            }
        }
    }
}

/** Appends dictated text to existing text, capitalizing the first letter of a new note. */
fun appendDictation(current: String, spoken: String): String {
    val text = spoken.trim().replaceFirstChar { it.uppercaseChar() }
    return when {
        current.isBlank() -> text
        current.endsWith("\n") || current.endsWith(" ") -> current + text
        current.trimEnd().endsWith(".") || current.trimEnd().endsWith("!") || current.trimEnd().endsWith("?") ->
            current.trimEnd() + " " + text
        else -> current.trimEnd() + ". " + text
    }
}
