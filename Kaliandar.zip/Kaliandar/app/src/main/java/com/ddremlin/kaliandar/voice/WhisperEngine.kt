package com.ddremlin.kaliandar.voice

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.sqrt

/** JNI bridge to whisper.cpp (src/main/cpp). */
object WhisperLib {
    init {
        System.loadLibrary("whisper_jni")
    }

    external fun initContext(path: String): Long
    external fun freeContext(ptr: Long)
    external fun transcribe(ptr: Long, samples: FloatArray, lang: String, threads: Int): ByteArray

    private val lock = Mutex()
    private var cachedPath: String? = null
    private var cachedPtr = 0L

    /** Loads the model once and keeps it, so the next dictation starts instantly. */
    suspend fun context(file: File): Long = lock.withLock {
        if (cachedPtr != 0L && cachedPath == file.absolutePath) return cachedPtr
        if (cachedPtr != 0L) freeContext(cachedPtr)
        cachedPtr = initContext(file.absolutePath)
        cachedPath = file.absolutePath
        cachedPtr
    }

    suspend fun unload() = lock.withLock {
        if (cachedPtr != 0L) freeContext(cachedPtr)
        cachedPtr = 0L
        cachedPath = null
    }
}

/**
 * Offline recognition with Whisper: records the microphone, cuts speech into phrases
 * by pauses (simple energy VAD) and transcribes each phrase in the background.
 */
class WhisperEngine(
    private val modelFile: File,
    private val language: String,
    private val scope: CoroutineScope,
    private val listener: Listener,
) {
    interface Listener {
        fun onListening()
        fun onText(text: String)
        fun onBusyChanged(busy: Boolean)
        /** Nobody spoke for [millis] and nothing is being transcribed. */
        fun onIdle(millis: Long)
        fun onError()
    }

    private val segments = Channel<FloatArray>(Channel.UNLIMITED)
    private var recordJob: Job? = null
    private var workerJob: Job? = null
    @Volatile private var recording = false
    private val pending = AtomicInteger(0)
    @Volatile private var stopped = false
    private val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)

    fun start() {
        scope.launch {
            val ctx = try {
                withContext(Dispatchers.IO) { WhisperLib.context(modelFile) }
            } catch (e: Throwable) {
                0L
            }
            if (stopped) return@launch
            if (ctx == 0L) {
                listener.onError()
                return@launch
            }
            workerJob = scope.launch(Dispatchers.Default) {
                for (samples in segments) {
                    val text = clean(WhisperLib.transcribe(ctx, samples, language, threads).decodeToString())
                    val left = pending.decrementAndGet()
                    withContext(Dispatchers.Main) {
                        if (text.isNotEmpty()) listener.onText(text)
                        listener.onBusyChanged(left > 0)
                    }
                }
            }
            recording = true
            recordJob = scope.launch(Dispatchers.IO) { recordLoop() }
            listener.onListening()
        }
    }

    /** Stops recording, transcribes what is left and returns when all text is delivered. */
    suspend fun finish() {
        stopped = true
        recording = false
        recordJob?.join()
        segments.close()
        workerJob?.join()
    }

    fun release() {
        stopped = true
        recording = false
        segments.close()
        workerJob?.cancel()
    }

    @SuppressLint("MissingPermission") // checked by the dialog before starting
    private suspend fun recordLoop() {
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, FRAME * 2 * 4),
            )
        } catch (e: Exception) {
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            withContext(Dispatchers.Main) { listener.onError() }
            return
        }

        val frame = ShortArray(FRAME)
        val preRoll = ArrayDeque<ShortArray>()
        val current = ArrayList<ShortArray>()
        var inSpeech = false
        var silentFrames = 0
        var loudFrames = 0
        var idleFrames = 0
        var noise = 0.0

        fun emit() {
            if (loudFrames >= 3) {
                val out = FloatArray(current.size * FRAME)
                var i = 0
                for (f in current) for (s in f) out[i++] = s / 32768f
                pending.incrementAndGet()
                if (!segments.trySend(out).isSuccess) pending.decrementAndGet()
            }
            current.clear()
            inSpeech = false
            silentFrames = 0
            loudFrames = 0
        }

        rec.startRecording()
        try {
            while (recording && scope.isActive) {
                val n = rec.read(frame, 0, FRAME)
                if (n <= 0) continue
                var sum = 0.0
                for (k in 0 until n) sum += frame[k].toDouble() * frame[k]
                val rms = sqrt(sum / n)
                val loud = rms > maxOf(noise * 3.0, 350.0)

                if (!inSpeech) {
                    noise = if (noise == 0.0) rms else noise * 0.95 + rms * 0.05
                    preRoll.addLast(frame.copyOf())
                    if (preRoll.size > 3) preRoll.removeFirst()
                    if (loud) {
                        inSpeech = true
                        current.addAll(preRoll)
                        preRoll.clear()
                        loudFrames = 1
                        idleFrames = 0
                    } else {
                        idleFrames++
                        if (pending.get() == 0 && idleFrames % 10 == 0) {
                            val ms = idleFrames * 100L
                            withContext(Dispatchers.Main) { listener.onIdle(ms) }
                        }
                    }
                } else {
                    current.add(frame.copyOf())
                    if (loud) {
                        loudFrames++
                        silentFrames = 0
                    } else {
                        silentFrames++
                    }
                    // end of phrase: 0.8 s pause, or Whisper's 30 s window is almost full
                    if (silentFrames >= 8 || current.size >= 280) {
                        emit()
                        withContext(Dispatchers.Main) { listener.onBusyChanged(true) }
                    }
                }
            }
            if (inSpeech) emit()
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
    }

    private companion object {
        const val RATE = 16000
        const val FRAME = 1600 // 100 ms

        /** Removes Whisper's typical non-speech output like "[музыка]" or "(смех)". */
        fun clean(text: String): String =
            text.replace(Regex("""\[[^\]]*]|\([^)]*\)|\*[^*]*\*"""), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
    }
}
