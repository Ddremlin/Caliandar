package com.ddremlin.kaliandar.ui

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.ddremlin.kaliandar.R
import com.ddremlin.kaliandar.data.Event
import com.ddremlin.kaliandar.data.ReminderOptions
import com.ddremlin.kaliandar.data.Repeat
import com.ddremlin.kaliandar.voice.SpeechParser
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

private enum class Ask { INITIAL, TITLE, DATE, TIME, REMINDER, NOTE, CONFIRM }

private data class Msg(val fromUser: Boolean, val text: String)

private const val DAY_MS = 86_400_000L

/**
 * Voice dialog that builds an event: the user says everything at once
 * ("завтра в 15:00 врач, напомни за час"); whatever is missing is asked back
 * one question at a time (title -> date -> time -> reminder -> note), then a summary is shown.
 * Each question can be answered by voice or with quick-answer chips.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceAssistant(
    onSave: (Event) -> Unit,
    onEdit: (Event) -> Unit,
    onClose: () -> Unit,
) {
    val locale = LocalConfiguration.current.locales[0]
    val context = LocalContext.current
    val parser = remember(locale) { SpeechParser(locale.language) }
    val today = remember { LocalDate.now() }

    // draft
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf<LocalDate?>(null) }
    var allDay by remember { mutableStateOf<Boolean?>(null) }
    var start by remember { mutableStateOf<Int?>(null) }
    var end by remember { mutableStateOf<Int?>(null) }
    var reminder by remember { mutableStateOf<Int?>(null) }
    var repeat by remember { mutableStateOf(Repeat.NONE) }
    var note by remember { mutableStateOf("") }
    var noteAsked by remember { mutableStateOf(false) }

    var ask by remember { mutableStateOf(Ask.INITIAL) }
    var askCount by remember { mutableIntStateOf(0) } // bumps on every (re)ask -> auto listen
    var autoListen by remember { mutableStateOf(true) }
    var pickDate by remember { mutableStateOf(false) }
    var pickTime by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<Msg>() }

    val questions = mapOf(
        Ask.INITIAL to stringResource(R.string.ask_initial),
        Ask.TITLE to stringResource(R.string.ask_title),
        Ask.DATE to stringResource(R.string.ask_date),
        Ask.TIME to stringResource(R.string.ask_time),
        Ask.REMINDER to stringResource(R.string.ask_reminder),
        Ask.NOTE to stringResource(R.string.ask_note),
        Ask.CONFIRM to stringResource(R.string.ask_confirm),
    )
    val notUnderstood = stringResource(R.string.not_understood)

    fun nextAsk(): Ask = when {
        title.isBlank() -> Ask.TITLE
        date == null -> Ask.DATE
        allDay != true && start == null -> Ask.TIME
        reminder == null -> Ask.REMINDER
        !noteAsked -> Ask.NOTE
        else -> Ask.CONFIRM
    }

    fun goNext() {
        ask = nextAsk()
        if (ask == Ask.NOTE) noteAsked = true
        messages += Msg(false, questions.getValue(ask))
        askCount++
    }

    fun retry() {
        messages += Msg(false, notUnderstood + " " + questions.getValue(ask))
        askCount++
    }

    /** Fills empty fields from what was understood in any answer. */
    fun fill(text: String, overrideTitle: Boolean) {
        val p = parser.parse(text)
        if (overrideTitle || title.isBlank()) if (p.title.isNotBlank()) title = p.title
        if (date == null) date = p.date
        if (p.allDay && start == null) allDay = true
        if (start == null && p.startMinute != null) {
            start = p.startMinute
            end = p.endMinute
            allDay = false
        }
        if (reminder == null) reminder = p.reminder
        if (p.repeat != null && repeat == Repeat.NONE) repeat = p.repeat
    }

    fun answer(text: String) {
        if (text.isBlank()) return
        messages += Msg(true, text)
        when (ask) {
            Ask.INITIAL -> fill(text, overrideTitle = true)
            Ask.TITLE -> {
                fill(text, overrideTitle = true)
                if (title.isBlank()) title = appendDictation("", text)
            }
            Ask.DATE -> {
                val before = date
                fill(text, overrideTitle = false)
                if (before == null && date == null) return retry()
            }
            Ask.TIME -> {
                fill(text, overrideTitle = false)
                if (allDay != true && start == null) return retry()
            }
            Ask.REMINDER -> {
                val r = parser.parseReminderAnswer(text) ?: return retry()
                reminder = r
            }
            Ask.NOTE -> if (!parser.isSkip(text)) note = appendDictation(note, text)
            Ask.CONFIRM -> {
                // corrections said at the end: "в 16", "напомни за 10 минут"
                val p = parser.parse(text)
                p.date?.let { date = it }
                p.startMinute?.let { start = it; end = p.endMinute; allDay = false }
                if (p.allDay) allDay = true
                p.reminder?.let { reminder = it }
                p.repeat?.let { repeat = it }
            }
        }
        goNext()
    }

    fun buildEvent(): Event {
        val s = start ?: 9 * 60
        val e = end?.takeIf { it > s } ?: (s + 60).coerceAtMost(23 * 60 + 59)
        return Event(
            title = title.trim(),
            description = note.trim(),
            date = (date ?: today).toEpochDay(),
            allDay = allDay == true,
            startMinute = s,
            endMinute = e,
            reminderMinutes = reminder ?: 15,
            repeat = repeat.name,
        )
    }

    val listen = rememberVoiceInput(prompt = questions[ask]) { answer(it) }

    LaunchedEffect(Unit) {
        if (messages.isEmpty()) {
            messages += Msg(false, questions.getValue(Ask.INITIAL))
            askCount++
        }
    }
    // Ask by voice automatically after each question
    LaunchedEffect(askCount) {
        if (askCount > 0 && autoListen && ask != Ask.CONFIRM) {
            delay(500)
            listen()
        }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size)
    }

    val dateFmt = remember(locale) { DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(locale) }
    val timeFmt = remember(locale) { DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(locale) }
    fun minuteText(m: Int) = LocalTime.of(m / 60, m % 60).format(timeFmt)

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, stringResource(R.string.cancel)) }
                    },
                    title = { Text(stringResource(R.string.assistant_title)) },
                )
            },
            bottomBar = {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(bottom = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    QuickAnswers(
                        ask = ask,
                        onText = { label, apply ->
                            autoListen = true
                            messages += Msg(true, label)
                            apply()
                            goNext()
                        },
                        setDate = { date = it },
                        setAllDay = { allDay = true },
                        setStart = { start = it; end = null; allDay = false },
                        setReminder = { reminder = it },
                        pickDate = { pickDate = true },
                        pickTime = { pickTime = true },
                        today = today,
                        minuteText = ::minuteText,
                    )
                    if (ask == Ask.CONFIRM) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp)) {
                            OutlinedButton(onClick = { onEdit(buildEvent()) }) { Text(stringResource(R.string.edit)) }
                            Button(onClick = { onSave(buildEvent()) }) { Text(stringResource(R.string.save)) }
                        }
                    }
                    Spacer(Modifier.size(8.dp))
                    FilledIconButton(
                        onClick = { autoListen = true; listen() },
                        modifier = Modifier.size(64.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(),
                    ) {
                        Icon(painterResource(R.drawable.ic_mic), stringResource(R.string.speak), Modifier.size(30.dp))
                    }
                }
            },
        ) { padding ->
            LazyColumn(
                state = listState,
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                itemsIndexed(messages) { _, msg -> Bubble(msg) }
                item {
                    if (title.isNotBlank() || date != null) {
                        Summary(
                            title = title,
                            date = date?.format(dateFmt)?.replaceFirstChar { it.titlecase(locale) },
                            time = when {
                                allDay == true -> stringResource(R.string.all_day)
                                start != null -> minuteText(start!!) + (end?.let { " – " + minuteText(it) } ?: "")
                                else -> null
                            },
                            reminder = reminder?.let { reminderLabel(it) },
                            repeat = repeat.takeIf { it != Repeat.NONE }?.let { repeatLabel(it) },
                            note = note,
                        )
                    }
                }
            }
        }
    }

    if (pickDate) {
        val state = rememberDatePickerState(initialSelectedDateMillis = (date ?: today).toEpochDay() * DAY_MS)
        DatePickerDialog(
            onDismissRequest = { pickDate = false },
            confirmButton = {
                TextButton(onClick = {
                    pickDate = false
                    state.selectedDateMillis?.let {
                        val d = LocalDate.ofEpochDay(Math.floorDiv(it, DAY_MS))
                        messages += Msg(true, d.format(dateFmt))
                        date = d
                        goNext()
                    }
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = { TextButton(onClick = { pickDate = false }) { Text(stringResource(R.string.cancel)) } },
        ) { DatePicker(state = state) }
    }

    if (pickTime) {
        val init = start ?: (9 * 60)
        val state = rememberTimePickerState(init / 60, init % 60, DateFormat.is24HourFormat(context))
        AlertDialog(
            onDismissRequest = { pickTime = false },
            confirmButton = {
                TextButton(onClick = {
                    pickTime = false
                    val m = state.hour * 60 + state.minute
                    messages += Msg(true, minuteText(m))
                    start = m
                    end = null
                    allDay = false
                    goNext()
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = { TextButton(onClick = { pickTime = false }) { Text(stringResource(R.string.cancel)) } },
            text = { TimePicker(state = state) },
        )
    }
}

@Composable
private fun QuickAnswers(
    ask: Ask,
    onText: (label: String, apply: () -> Unit) -> Unit,
    setDate: (LocalDate) -> Unit,
    setAllDay: () -> Unit,
    setStart: (Int) -> Unit,
    setReminder: (Int) -> Unit,
    pickDate: () -> Unit,
    pickTime: () -> Unit,
    today: LocalDate,
    minuteText: (Int) -> String,
) {
    val chips: List<Pair<String, () -> Unit>> = when (ask) {
        Ask.DATE -> {
            val t = stringResource(R.string.today)
            val tm = stringResource(R.string.tomorrow)
            val atm = stringResource(R.string.after_tomorrow)
            listOf(
                t to { onText(t) { setDate(today) } },
                tm to { onText(tm) { setDate(today.plusDays(1)) } },
                atm to { onText(atm) { setDate(today.plusDays(2)) } },
                stringResource(R.string.pick) to pickDate,
            )
        }
        Ask.TIME -> {
            val ad = stringResource(R.string.all_day)
            listOf(ad to { onText(ad) { setAllDay() } }) +
                listOf(9, 12, 15, 18).map { h ->
                    val label = minuteText(h * 60)
                    label to { onText(label) { setStart(h * 60) } }
                } +
                listOf(stringResource(R.string.pick) to pickTime)
        }
        Ask.REMINDER -> ReminderOptions.map { m ->
            val label = reminderLabel(m)
            label to { onText(label) { setReminder(m) } }
        }
        Ask.NOTE -> {
            val s = stringResource(R.string.skip)
            listOf(s to { onText(s) { } })
        }
        else -> emptyList()
    }
    if (chips.isEmpty()) return
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(chips) { (label, action) ->
            SuggestionChip(onClick = action, label = { Text(label) })
        }
    }
}

@Composable
private fun Bubble(msg: Msg) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier
                .widthIn(max = 300.dp)
                .background(
                    if (msg.fromUser) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant,
                    RoundedCornerShape(16.dp),
                )
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            Text(
                msg.text,
                color = if (msg.fromUser) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun Summary(
    title: String,
    date: String?,
    time: String?,
    reminder: String?,
    repeat: String?,
    note: String,
) {
    Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title.ifBlank { "…" }, style = MaterialTheme.typography.titleMedium)
            Line(stringResource(R.string.date), date)
            Line(stringResource(R.string.start), time)
            Line(stringResource(R.string.reminder), reminder)
            if (repeat != null) Line(stringResource(R.string.repeat), repeat)
            if (note.isNotBlank()) Line(stringResource(R.string.description), note)
        }
    }
}

@Composable
private fun Line(label: String, value: String?) {
    Row {
        Text("$label: ", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value ?: "—", style = MaterialTheme.typography.bodyMedium)
    }
}
