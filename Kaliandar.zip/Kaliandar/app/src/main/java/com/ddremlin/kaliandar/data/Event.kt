package com.ddremlin.kaliandar.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate
import java.time.LocalTime

enum class Repeat { NONE, DAILY, WEEKLY, MONTHLY, YEARLY }

@Entity(tableName = "events")
data class Event(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    /** Day of the (first) occurrence, as LocalDate.toEpochDay() */
    val date: Long,
    val allDay: Boolean = false,
    /** Minutes from midnight */
    val startMinute: Int = 9 * 60,
    val endMinute: Int = 10 * 60,
    /** Index in [EventColors] */
    val color: Int = 0,
    /** Minutes before start, or -1 for no reminder */
    val reminderMinutes: Int = 15,
    val repeat: String = Repeat.NONE.name,
)

val Event.localDate: LocalDate get() = LocalDate.ofEpochDay(date)
val Event.startTime: LocalTime get() = LocalTime.of(startMinute / 60, startMinute % 60)
val Event.endTime: LocalTime get() = LocalTime.of(endMinute / 60, endMinute % 60)
val Event.repeatType: Repeat get() = runCatching { Repeat.valueOf(repeat) }.getOrDefault(Repeat.NONE)

/** ARGB colors for events */
val EventColors = listOf(
    0xFF1E5BB8, 0xFFE53935, 0xFF43A047, 0xFFFB8C00,
    0xFF8E24AA, 0xFF00ACC1, 0xFF6D4C41, 0xFF546E7A,
)

val ReminderOptions = listOf(-1, 0, 5, 15, 30, 60, 1440)
