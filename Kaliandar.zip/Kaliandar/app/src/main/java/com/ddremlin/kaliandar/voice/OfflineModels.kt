package com.ddremlin.kaliandar.voice

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

enum class OfflineEngine { VOSK, WHISPER }

data class OfflineModel(
    val id: String,
    val engine: OfflineEngine,
    val url: String,
    val sizeMb: Int,
    /** Vosk models come as a zip with a folder; Whisper is a single .bin file */
    val zipped: Boolean,
)

/** Offline speech models, downloaded once on demand. */
object OfflineModels {
    private const val VOSK = "https://alphacephei.com/vosk/models/"

    fun forLanguage(lang: String): OfflineModel = when (lang) {
        // Belarusian: Whisper Small fine-tuned on Belarusian Common Voice (whisper.cpp, q8_0)
        "be" -> OfflineModel(
            id = "whisper-small-be-q8",
            engine = OfflineEngine.WHISPER,
            url = "https://huggingface.co/dziaineka/whisper-small-belarusian/resolve/main/run_5/ggml/ggml-model-q8_0.bin",
            sizeMb = 252,
            zipped = false,
        )
        "ru" -> vosk("vosk-model-small-ru-0.22", 45)
        "pl" -> vosk("vosk-model-small-pl-0.22", 50)
        "uk" -> vosk("vosk-model-small-uk-v3-nano", 73)
        else -> vosk("vosk-model-small-en-us-0.15", 40)
    }

    private fun vosk(name: String, mb: Int) =
        OfflineModel(name, OfflineEngine.VOSK, "$VOSK$name.zip", mb, zipped = true)

    fun dir(context: Context, model: OfflineModel) = File(context.filesDir, "speech/${model.id}")

    /** For Whisper: the model file. For Vosk: the model folder. */
    fun path(context: Context, model: OfflineModel): File =
        if (model.zipped) dir(context, model) else File(dir(context, model), "model.bin")

    fun isReady(context: Context, model: OfflineModel) = File(dir(context, model), ".ready").exists()

    fun delete(context: Context, model: OfflineModel) {
        dir(context, model).deleteRecursively()
    }

    /** Downloads (and unpacks) the model. [onProgress] gets 0..1. Throws on failure. */
    suspend fun download(context: Context, model: OfflineModel, onProgress: (Float) -> Unit) =
        withContext(Dispatchers.IO) {
            val target = dir(context, model)
            target.deleteRecursively()
            target.mkdirs()
            val tmp = File(context.cacheDir, "${model.id}.part")
            try {
                val conn = (URL(model.url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15_000
                    readTimeout = 30_000
                    instanceFollowRedirects = true
                }
                try {
                    if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
                    val total = conn.contentLengthLong
                    conn.inputStream.use { input -> copy(input, tmp, total, onProgress) { ensureActive() } }
                } finally {
                    conn.disconnect()
                }

                if (model.zipped) {
                    unzip(tmp, target)
                } else {
                    val dest = path(context, model)
                    if (!tmp.renameTo(dest)) tmp.copyTo(dest, overwrite = true)
                }
                File(target, ".ready").createNewFile()
                onProgress(1f)
            } catch (e: Exception) {
                target.deleteRecursively()
                throw e
            } finally {
                tmp.delete()
            }
        }

    private inline fun copy(
        input: InputStream,
        file: File,
        total: Long,
        onProgress: (Float) -> Unit,
        checkCancelled: () -> Unit,
    ) {
        file.outputStream().use { out ->
            val buf = ByteArray(64 * 1024)
            var done = 0L
            var reported = 0L
            while (true) {
                checkCancelled()
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                done += n
                if (total > 0 && done - reported > 512 * 1024) {
                    reported = done
                    onProgress(done.toFloat() / total * 0.95f)
                }
            }
        }
    }

    private fun unzip(zipFile: File, target: File) {
        val root = target.canonicalPath + File.separator
        ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                // Strip the top folder ("vosk-model-.../am/final.mdl" -> "am/final.mdl")
                val rel = entry.name.substringAfter('/', "")
                if (rel.isNotEmpty()) {
                    val file = File(target, rel)
                    if (!file.canonicalPath.startsWith(root)) throw IOException("Bad zip entry")
                    if (entry.isDirectory) {
                        file.mkdirs()
                    } else {
                        file.parentFile?.mkdirs()
                        file.outputStream().use { zip.copyTo(it) }
                    }
                }
                zip.closeEntry()
            }
        }
    }
}
