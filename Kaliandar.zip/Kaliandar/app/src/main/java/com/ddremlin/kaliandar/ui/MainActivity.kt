package com.ddremlin.kaliandar.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.LaunchedEffect
import com.ddremlin.kaliandar.overlay.FloatingMicService
import com.ddremlin.kaliandar.ui.theme.KaliandarTheme

class MainActivity : AppCompatActivity() {
    private val vm: CalendarViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KaliandarTheme {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val launcher = rememberLauncherForActivityResult(
                        ActivityResultContracts.RequestPermission()
                    ) { }
                    LaunchedEffect(Unit) {
                        launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                CalendarScreen(vm)
            }
        }
        EventExtras.take(intent)?.let { vm.edit(it) }
        FloatingMicService.startIfEnabled(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        EventExtras.take(intent)?.let { vm.edit(it) }
    }

    override fun onStart() {
        super.onStart()
        FloatingMicService.appVisible.value = true
    }

    override fun onStop() {
        super.onStop()
        FloatingMicService.appVisible.value = false
    }
}
