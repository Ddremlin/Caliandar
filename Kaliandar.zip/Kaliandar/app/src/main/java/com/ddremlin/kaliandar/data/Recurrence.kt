package com.ddremlin.kaliandar.data

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

/** Does [event] have an occurrence on [day]? */
fun Event.occursOn(day: LocalDate): Boolean {
    val first = localDate
    if (day.isBefore(first)) return false
    return when (repeatType) {
        Repeat.NONE -> day == first
        Repeat.DAILY -> true
        Repeat.WEEKLY -> day.dayOfWeek == first.dayOfWeek
        Repeat.MONTHLY -> day.dayOfMonth == first.dayOfMonth
        Repeat.YEARLY -> day.month == first.month && day.dayOfMonth == first.dayOfMonth
    }
}

/** Events happening on [day], sorted: all-day first, then by start time. */
fun List<Event>.on(day: LocalDate): List<Event> =
    filter { it.occursOn(day) }.sortedWith(compareBy({ !it.allDay }, { it.startMinute }))

/** All-day events get their reminder relative to 09:00. */
private val ALL_DAY_BASE: LocalTime = LocalTime.of(9, 0)

/** Next moment (after [now]) when a reminder for this event should fire, or null. */
fun Event.nextReminderTime(now: LocalDateTime = LocalDateTime.now()): LocalDateTime? {
    if (reminderMinutes < 0) return null
    val today = now.toLocalDate()
    var day: LocalDate = if (localDate.isAfter(today)) localDate else today
    // 1500 days covers yearly events on Feb 29
    for (i in 0 until 1500) {
        if (occursOn(day)) {
            val start = day.atTime(if (allDay) ALL_DAY_BASE else startTime)
            val fire = start.minusMinutes(reminderMinutes.toLong())
            if (fire.isAfter(now)) return fire
        }
        if (repeatType == Repeat.NONE && day.isAfter(localDate)) return null
        day = day.plusDays(1)
    }
    return null
}
