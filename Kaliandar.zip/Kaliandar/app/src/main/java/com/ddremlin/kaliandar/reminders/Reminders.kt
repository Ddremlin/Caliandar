package com.ddremlin.kaliandar.reminders

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ddremlin.kaliandar.KaliandarApp
import com.ddremlin.kaliandar.R
import com.ddremlin.kaliandar.data.AppDatabase
import com.ddremlin.kaliandar.data.Event
import com.ddremlin.kaliandar.data.endTime
import com.ddremlin.kaliandar.data.nextReminderTime
import com.ddremlin.kaliandar.data.startTime
import com.ddremlin.kaliandar.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object ReminderScheduler {
    private const val EXTRA_ID = "event_id"

    fun schedule(context: Context, event: Event) {
        val am = context.getSystemService(AlarmManager::class.java)
        val pi = pendingIntent(context, event.id)
        am.cancel(pi)
        val time = event.nextReminderTime() ?: return
        val millis = time.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        try {
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
        }
    }

    fun cancel(context: Context, eventId: Long) {
        context.getSystemService(AlarmManager::class.java).cancel(pendingIntent(context, eventId))
    }

    suspend fun rescheduleAll(context: Context) {
        AppDatabase.get(context).events().getAll().forEach { schedule(context, it) }
    }

    fun eventId(intent: Intent): Long = intent.getLongExtra(EXTRA_ID, -1)

    private fun pendingIntent(context: Context, eventId: Long): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).putExtra(EXTRA_ID, eventId)
        return PendingIntent.getBroadcast(
            context,
            eventId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = ReminderScheduler.eventId(intent)
        if (id < 0) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val event = AppDatabase.get(context).events().get(id) ?: return@launch
                showNotification(context, event)
                // Schedule the next occurrence of a repeating event
                ReminderScheduler.schedule(context, event)
            } finally {
                pending.finish()
            }
        }
    }

    private fun showNotification(context: Context, event: Event) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val open = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val fmt = DateTimeFormatter.ofPattern("HH:mm")
        val time = if (event.allDay) context.getString(R.string.all_day)
        else "${event.startTime.format(fmt)}–${event.endTime.format(fmt)}"
        val text = if (event.description.isBlank()) time else "$time · ${event.description}"

        val notification = NotificationCompat.Builder(context, KaliandarApp.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(event.title.ifBlank { context.getString(R.string.no_title) })
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(event.id.toInt(), notification)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                ReminderScheduler.rescheduleAll(context)
                if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
                    kotlinx.coroutines.withContext(Dispatchers.Main) {
                        com.ddremlin.kaliandar.overlay.FloatingMicService.startIfEnabled(context)
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }
}
