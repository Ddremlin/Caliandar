package com.ddremlin.kaliandar.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.util.Locale
import org.vosk.android.RecognitionListener as VoskListener

sealed interface VoiceState {
    data object Starting : VoiceState
    data class Listening(val offline: Boolean) : VoiceState
    data object LoadingModel : VoiceState
    data class NeedModel(val sizeMb: Int) : VoiceState
    data class Downloading(val progress: Float) : VoiceState
    data object DownloadFailed : VoiceState
    data object NoPermission : VoiceState
    data object Error : VoiceState
}

/**
 * Speech-to-text that keeps working in every situation:
 * 1. on-device system recognizer (Android 12+, offline),
 * 2. regular system recognizer (Google, usually online),
 * 3. built-in offline engine with a downloaded model: Vosk, or Whisper for Belarusian.
 * If an engine fails (no internet, language not supported, no recognizer at all),
 * the next one is used automatically. Listening is continuous until [currentText] is taken.
 */
class VoiceController(
    private val context: Context,
    private val locale: Locale,
    private val scope: CoroutineScope,
) {
    var state by mutableStateOf<VoiceState>(VoiceState.Starting)
        internal set
    var committed by mutableStateOf("")
        private set
    var partial by mutableStateOf("")
        private set
    /** Becomes true when the user stopped talking for a while. */
    var autoFinished by mutableStateOf(false)
        private set

    /** Offline Whisper is still transcribing recorded phrases. */
    var processing by mutableStateOf(false)
        private set

    val currentText: String get() = join(committed, partial)

    private val model = OfflineModels.forLanguage(locale.language)
    private var whisper: WhisperEngine? = null
    private var finishing = false
    private val systemFactories = ArrayDeque<() -> SpeechRecognizer>()
    private var recognizer: SpeechRecognizer? = null
    private var silentRounds = 0
    private var clientErrors = 0

    private var voskModel: Model? = null
    private var voskRecognizer: Recognizer? = null
    private var voskService: SpeechService? = null
    private var released = false

    fun start() {
        systemFactories.clear()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        ) {
            systemFactories.add { SpeechRecognizer.createOnDeviceSpeechRecognizer(context) }
        }
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            systemFactories.add { SpeechRecognizer.createSpeechRecognizer(context) }
        }
        nextEngine()
    }

    fun downloadModel() {
        state = VoiceState.Downloading(0f)
        scope.launch {
            try {
                OfflineModels.download(context, model) { state = VoiceState.Downloading(it) }
                startOffline()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                state = VoiceState.DownloadFailed
            }
        }
    }

    /** Stops listening and delivers the final text (waits for Whisper to finish transcribing). */
    fun finish(deliver: (String) -> Unit) {
        if (finishing) return
        finishing = true
        val w = whisper
        if (w == null) {
            deliver(currentText)
            return
        }
        processing = true
        scope.launch {
            w.finish()
            processing = false
            partial = ""
            deliver(currentText)
        }
    }

    fun release() {
        released = true
        whisper?.release()
        whisper = null
        destroyRecognizer()
        voskService?.let {
            it.stop()
            it.shutdown()
        }
        voskService = null
        voskRecognizer?.close()
        voskRecognizer = null
        voskModel?.close()
        voskModel = null
    }

    // ---------- system recognizer ----------

    private fun nextEngine() {
        if (released) return
        destroyRecognizer()
        val factory = systemFactories.removeFirstOrNull()
        if (factory == null) {
            startOffline()
            return
        }
        val r = try {
            factory()
        } catch (e: Exception) {
            nextEngine()
            return
        }
        recognizer = r
        clientErrors = 0
        r.setRecognitionListener(systemListener(r))
        listen()
    }

    private fun listen() {
        val r = recognizer ?: return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            nextEngine()
        }
    }

    private fun systemListener(r: SpeechRecognizer) = object : RecognitionListener {
        private fun current() = !released && recognizer === r

        override fun onReadyForSpeech(params: Bundle?) {
            if (current()) state = VoiceState.Listening(offline = false)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (!current()) return
            first(partialResults)?.let { partial = it }
        }

        override fun onResults(results: Bundle?) {
            if (!current()) return
            val text = first(results)
            if (text.isNullOrBlank()) {
                silence()
            } else {
                committed = join(committed, text)
                partial = ""
                silentRounds = 0
                listen() // keep listening until the user taps "Done"
            }
        }

        override fun onError(error: Int) {
            if (!current()) return
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> silence()
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> scope.launch {
                    delay(400)
                    if (current()) listen()
                }
                SpeechRecognizer.ERROR_CLIENT -> {
                    // Sometimes happens right after a restart; retry a few times
                    if (++clientErrors <= 3) scope.launch {
                        delay(250)
                        if (current()) listen()
                    } else nextEngine()
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> state = VoiceState.NoPermission
                // Network, server, language not supported/unavailable, audio...: try the next engine
                else -> {
                    if (partial.isNotBlank()) {
                        committed = join(committed, partial)
                        partial = ""
                    }
                    nextEngine()
                }
            }
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun silence() {
        if (partial.isNotBlank()) {
            committed = join(committed, partial)
            partial = ""
        }
        silentRounds++
        if ((committed.isNotBlank() && silentRounds >= 2) || silentRounds >= 3) {
            autoFinished = true
        } else {
            listen()
        }
    }

    private fun destroyRecognizer() {
        recognizer?.let {
            recognizer = null
            runCatching { it.cancel() }
            runCatching { it.destroy() }
        }
    }

    // ---------- offline Vosk ----------

    private fun startOffline() {
        if (released) return
        if (!OfflineModels.isReady(context, model)) {
            state = VoiceState.NeedModel(model.sizeMb)
            return
        }
        state = VoiceState.LoadingModel
        if (model.engine == OfflineEngine.WHISPER) startWhisper() else startVosk()
    }

    private fun startWhisper() {
        val engine = WhisperEngine(
            modelFile = OfflineModels.path(context, model),
            language = locale.language,
            scope = scope,
            listener = object : WhisperEngine.Listener {
                override fun onListening() {
                    if (!released) state = VoiceState.Listening(offline = true)
                }

                override fun onText(text: String) {
                    committed = join(committed, text)
                }

                override fun onBusyChanged(busy: Boolean) {
                    partial = if (busy) "…" else ""
                }

                override fun onIdle(millis: Long) {
                    if ((committed.isNotBlank() && millis >= 4000) || millis >= 10000) autoFinished = true
                }

                override fun onError() {
                    state = VoiceState.Error
                }
            },
        )
        whisper = engine
        engine.start()
    }

    private fun startVosk() {
        scope.launch {
            try {
                val m = voskModel ?: withContext(Dispatchers.IO) {
                    Model(OfflineModels.path(context, model).absolutePath)
                }
                voskModel = m
                if (released) {
                    release()
                    return@launch
                }
                val rec = Recognizer(m, SAMPLE_RATE)
                voskRecognizer = rec
                voskService = SpeechService(rec, SAMPLE_RATE).also { it.startListening(voskListener) }
                state = VoiceState.Listening(offline = true)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                state = VoiceState.Error
            }
        }
    }

    private val voskListener = object : VoskListener {
        override fun onPartialResult(hypothesis: String?) {
            partial = field(hypothesis, "partial")
        }

        override fun onResult(hypothesis: String?) {
            commit(field(hypothesis, "text"))
        }

        override fun onFinalResult(hypothesis: String?) {
            commit(field(hypothesis, "text"))
        }

        override fun onError(exception: Exception?) {
            state = VoiceState.Error
        }

        override fun onTimeout() {}

        private fun commit(text: String) {
            if (text.isNotBlank()) committed = join(committed, text)
            partial = ""
        }
    }

    private companion object {
        const val SAMPLE_RATE = 16000f

        fun first(b: Bundle?): String? =
            b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()

        fun field(json: String?, name: String): String =
            runCatching { JSONObject(json ?: "{}").optString(name, "") }.getOrDefault("")

        fun join(a: String, b: String) = when {
            a.isBlank() -> b.trim()
            b.isBlank() -> a.trim()
            else -> a.trim() + " " + b.trim()
        }
    }
}
