package com.ddremlin.kaliandar.ui

import android.content.Context
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ddremlin.kaliandar.R
import com.ddremlin.kaliandar.data.Event
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

enum class DayView { BLOCK, LINEAR, GRID }

private fun currentMinute(): Int = LocalTime.now().let { it.hour * 60 + it.minute }

/** Current minute of the day, refreshed every 30 s so the red line moves. */
@Composable
private fun rememberNowMinute(): Int {
    var now by remember { mutableIntStateOf(currentMinute()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = currentMinute()
        }
    }
    return now
}

private const val SLOT = 30 // minutes
private const val SLOTS = 24 * 60 / SLOT
private val SLOT_H = 36.dp
private val LABEL_W = 52.dp

private object DayViewPrefs {
    fun get(c: Context): DayView = runCatching {
        DayView.valueOf(c.getSharedPreferences("ui", Context.MODE_PRIVATE).getString("day_view", null)!!)
    }.getOrDefault(DayView.BLOCK)

    fun set(c: Context, v: DayView) =
        c.getSharedPreferences("ui", Context.MODE_PRIVATE).edit().putString("day_view", v.name).apply()
}

/**
 * Half-hour schedule of one day with three views:
 * BLOCK — time line with events as blocks sized by duration,
 * LINEAR — list of all half-hour slots with what happens in each,
 * GRID — table of hours x (:00, :30) cells, busy cells colored.
 * Tap an empty slot to create an event at that time.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DaySchedule(
    day: LocalDate,
    dayEvents: List<Event>,
    locale: Locale,
    onEdit: (Event) -> Unit,
    onNewAt: (minute: Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf(DayViewPrefs.get(context)) }
    val allDay = dayEvents.filter { it.allDay }
    val timed = dayEvents.filter { !it.allDay }
    val timeFmt = remember(locale) { DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(locale) }
    fun t(m: Int) = LocalTime.of((m / 60).coerceIn(0, 23), m % 60).format(timeFmt)

    Column(modifier) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                DateTimeFormatter.ofPattern("EEEE, d MMMM", locale).format(day).replaceFirstChar { it.titlecase(locale) },
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val options = listOf(
                Triple(DayView.BLOCK, R.drawable.ic_view_block, R.string.view_block),
                Triple(DayView.LINEAR, R.drawable.ic_view_linear, R.string.view_linear),
                Triple(DayView.GRID, R.drawable.ic_view_grid, R.string.view_grid),
            )
            SingleChoiceSegmentedButtonRow {
                options.forEachIndexed { i, (v, icon, label) ->
                    SegmentedButton(
                        selected = mode == v,
                        onClick = {
                            mode = v
                            DayViewPrefs.set(context, v)
                        },
                        shape = SegmentedButtonDefaults.itemShape(i, options.size),
                        icon = {},
                    ) {
                        Icon(painterResource(icon), contentDescription = stringResource(label), Modifier.size(18.dp))
                    }
                }
            }
        }

        if (allDay.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(allDay) { e ->
                    Text(
                        e.title.ifBlank { stringResource(R.string.no_title) },
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(eventColor(e))
                            .clickable { onEdit(e) }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                    )
                }
            }
        }

        val scroll = rememberScrollState()
        val density = LocalDensity.current
        // Open at the first event, the current time (today) or 8:00
        LaunchedEffect(day, mode) {
            val now = LocalTime.now()
            val focus = timed.minOfOrNull { it.startMinute }
                ?: if (day == LocalDate.now()) now.hour * 60 + now.minute else 8 * 60
            val slot = (focus / SLOT - 1).coerceAtLeast(0)
            val rowPx = with(density) {
                when (mode) {
                    DayView.BLOCK -> SLOT_H.toPx()
                    DayView.LINEAR -> 44.dp.toPx()
                    DayView.GRID -> 44.dp.toPx() / 2
                }
            }
            scroll.scrollTo((slot * rowPx).toInt())
        }

        val nowMinute = rememberNowMinute()
        val now = if (day == LocalDate.now()) nowMinute else null // red line only for today
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (mode) {
                DayView.BLOCK -> BlockView(now, timed, scroll, ::t, onEdit, onNewAt)
                DayView.LINEAR -> LinearView(now, timed, scroll, ::t, onEdit, onNewAt)
                DayView.GRID -> GridView(now, timed, scroll, ::t, onEdit, onNewAt)
            }
        }
    }
}

private fun Event.endSafe() = if (endMinute > startMinute) endMinute else startMinute + SLOT

private fun Event.inSlot(slotStart: Int) = startMinute < slotStart + SLOT && endSafe() > slotStart

/** Side-by-side columns for overlapping events: event -> (column, columns in its group). */
private fun columns(list: List<Event>): List<Triple<Event, Int, Int>> {
    val sorted = list.sortedWith(compareBy({ it.startMinute }, { -it.endSafe() }))
    val result = mutableListOf<Triple<Event, Int, Int>>()
    var group = mutableListOf<Pair<Event, Int>>()
    var colEnds = mutableListOf<Int>()
    var groupEnd = -1
    fun flush() {
        val n = colEnds.size.coerceAtLeast(1)
        group.forEach { (e, c) -> result += Triple(e, c, n) }
        group = mutableListOf()
        colEnds = mutableListOf()
    }
    for (e in sorted) {
        if (e.startMinute >= groupEnd && group.isNotEmpty()) flush()
        val col = colEnds.indexOfFirst { it <= e.startMinute }.let { if (it < 0) colEnds.size else it }
        if (col == colEnds.size) colEnds += e.endSafe() else colEnds[col] = e.endSafe()
        group += e to col
        groupEnd = maxOf(groupEnd, e.endSafe())
    }
    flush()
    return result
}

@Composable
private fun SlotLines(index: Int): Modifier {
    val strong = MaterialTheme.colorScheme.outlineVariant
    val weak = strong.copy(alpha = 0.45f)
    return Modifier.drawBehind {
        drawLine(if (index % 2 == 0) strong else weak, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = 1f)
    }
}

@Composable
private fun BlockView(
    now: Int?,
    timed: List<Event>,
    scroll: ScrollState,
    t: (Int) -> String,
    onEdit: (Event) -> Unit,
    onNewAt: (Int) -> Unit,
) {
    val laid = remember(timed) { columns(timed) }
    Row(Modifier.fillMaxSize().verticalScroll(scroll).height(SLOT_H * SLOTS)) {
        Column(Modifier.width(LABEL_W)) {
            repeat(SLOTS) { i ->
                Box(Modifier.height(SLOT_H).fillMaxWidth().padding(start = 8.dp)) {
                    Text(
                        t(i * SLOT),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (i % 2 == 0) 1f else 0.55f),
                    )
                }
            }
        }
        BoxWithConstraints(Modifier.weight(1f).fillMaxHeight().padding(end = 8.dp)) {
            Column {
                repeat(SLOTS) { i ->
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(SLOT_H)
                            .then(SlotLines(i))
                            .clickable { onNewAt(i * SLOT) }
                    )
                }
            }
            val width = maxWidth
            laid.forEach { (e, col, cols) ->
                val colW = width / cols
                val duration = (e.endSafe() - e.startMinute).coerceAtLeast(SLOT / 2)
                Column(
                    Modifier
                        .offset(x = colW * col, y = SLOT_H * (e.startMinute / SLOT.toFloat()))
                        .width(colW)
                        .height(SLOT_H * (duration / SLOT.toFloat()))
                        .padding(1.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(eventColor(e).copy(alpha = 0.9f))
                        .clickable { onEdit(e) }
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                ) {
                    Text(
                        e.title.ifBlank { stringResource(R.string.no_title) },
                        color = Color.White,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = if (duration >= 60) 2 else 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (duration >= 45) Text(
                        "${t(e.startMinute)} – ${t(e.endSafe().coerceAtMost(23 * 60 + 59))}",
                        color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                    )
                }
            }
            // current time line
            if (now != null) {
                val y = SLOT_H * (now / SLOT.toFloat())
                val red = MaterialTheme.colorScheme.error
                Box(Modifier.offset(y = y - 1.dp).fillMaxWidth().height(2.dp).background(red))
                Box(Modifier.offset(x = (-4).dp, y = y - 4.dp).size(8.dp).clip(CircleShape).background(red))
            }
        }
    }
}

@Composable
private fun LinearView(
    now: Int?,
    timed: List<Event>,
    scroll: ScrollState,
    t: (Int) -> String,
    onEdit: (Event) -> Unit,
    onNewAt: (Int) -> Unit,
) {
    Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
        repeat(SLOTS) { i ->
            val slotStart = i * SLOT
            val here = timed.filter { it.inSlot(slotStart) }.sortedBy { it.startMinute }
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 44.dp)
                    .then(SlotLines(i))
                    .then(nowLine(now, slotStart, vertical = false))
                    .clickable(enabled = here.isEmpty()) { onNewAt(slotStart) }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    t(slotStart),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (i % 2 == 0) FontWeight.Bold else FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(LABEL_W).padding(start = 8.dp),
                )
                Column(Modifier.weight(1f).padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    here.forEach { e ->
                        val starts = e.startMinute >= slotStart
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(eventColor(e).copy(alpha = if (starts) 0.9f else 0.35f))
                                .clickable { onEdit(e) }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                        ) {
                            Text(
                                (if (starts) "" else "↳ ") + e.title.ifBlank { stringResource(R.string.no_title) },
                                color = if (starts) Color.White else MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            if (starts) Text(
                                "${t(e.startMinute)} – ${t(e.endSafe().coerceAtMost(23 * 60 + 59))}",
                                color = Color.White.copy(alpha = 0.85f),
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GridView(
    now: Int?,
    timed: List<Event>,
    scroll: ScrollState,
    t: (Int) -> String,
    onEdit: (Event) -> Unit,
    onNewAt: (Int) -> Unit,
) {
    val border = MaterialTheme.colorScheme.outlineVariant
    Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 8.dp)) {
        repeat(24) { h ->
            Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    t(h * 60),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(LABEL_W - 8.dp),
                )
                for (half in 0..1) {
                    val slotStart = h * 60 + half * SLOT
                    val here = timed.filter { it.inSlot(slotStart) }.sortedBy { it.startMinute }
                    val first = here.firstOrNull()
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(1.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .border(
                                if (now != null && now in slotStart until slotStart + SLOT) 2.dp else 1.dp,
                                if (now != null && now in slotStart until slotStart + SLOT) MaterialTheme.colorScheme.error else border,
                                RoundedCornerShape(4.dp),
                            )
                            .background(first?.let { eventColor(it).copy(alpha = 0.85f) } ?: Color.Transparent)
                            // time runs left -> right inside the half-hour cell
                            .then(nowLine(now, slotStart, vertical = true))
                            .clickable { if (first != null) onEdit(first) else onNewAt(slotStart) }
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        if (first != null) {
                            Text(
                                first.title.ifBlank { stringResource(R.string.no_title) } +
                                    if (here.size > 1) "  +${here.size - 1}" else "",
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                        } else {
                            Text(
                                ":" + (if (half == 0) "00" else "30"),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Red "now" line inside a half-hour slot, at the exact minute:
 * horizontal (top -> bottom) for list rows, vertical (left -> right) for grid cells.
 */
@Composable
private fun nowLine(now: Int?, slotStart: Int, vertical: Boolean): Modifier {
    if (now == null || now !in slotStart until slotStart + SLOT) return Modifier
    val red = MaterialTheme.colorScheme.error
    val fraction = (now - slotStart) / SLOT.toFloat()
    return Modifier.drawWithContent {
        drawContent()
        val stroke = 2.dp.toPx()
        if (vertical) {
            val x = size.width * fraction
            drawLine(red, Offset(x, 0f), Offset(x, size.height), strokeWidth = stroke)
            drawCircle(red, radius = 4.dp.toPx(), center = Offset(x, 0f))
        } else {
            val y = size.height * fraction
            drawLine(red, Offset(0f, y), Offset(size.width, y), strokeWidth = stroke)
            drawCircle(red, radius = 4.dp.toPx(), center = Offset(4.dp.toPx(), y))
        }
    }
}
