#include <jni.h>
#include <string>
#include <android/log.h>
#include "whisper.h"

#define TAG "WhisperJNI"

extern "C" JNIEXPORT jlong JNICALL
Java_com_ddremlin_kaliandar_voice_WhisperLib_initContext(JNIEnv *env, jobject, jstring path) {
    const char *p = env->GetStringUTFChars(path, nullptr);
    whisper_context_params cparams = whisper_context_default_params();
    whisper_context *ctx = whisper_init_from_file_with_params(p, cparams);
    env->ReleaseStringUTFChars(path, p);
    if (!ctx) __android_log_print(ANDROID_LOG_ERROR, TAG, "Failed to load model");
    return reinterpret_cast<jlong>(ctx);
}

extern "C" JNIEXPORT void JNICALL
Java_com_ddremlin_kaliandar_voice_WhisperLib_freeContext(JNIEnv *, jobject, jlong ptr) {
    if (ptr) whisper_free(reinterpret_cast<whisper_context *>(ptr));
}

// Returns UTF-8 bytes (not jstring: whisper may emit sequences that are not valid "modified UTF-8")
extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_ddremlin_kaliandar_voice_WhisperLib_transcribe(JNIEnv *env, jobject, jlong ptr,
                                                       jfloatArray samples, jstring lang, jint threads) {
    auto *ctx = reinterpret_cast<whisper_context *>(ptr);
    std::string out;
    if (ctx) {
        const char *language = env->GetStringUTFChars(lang, nullptr);
        whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
        params.print_realtime = false;
        params.print_progress = false;
        params.print_timestamps = false;
        params.print_special = false;
        params.translate = false;
        params.language = language;
        params.n_threads = threads;
        params.no_context = true;
        params.suppress_blank = true;

        jsize n = env->GetArrayLength(samples);
        jfloat *data = env->GetFloatArrayElements(samples, nullptr);
        if (whisper_full(ctx, params, data, n) == 0) {
            int segments = whisper_full_n_segments(ctx);
            for (int i = 0; i < segments; ++i) out += whisper_full_get_segment_text(ctx, i);
        }
        env->ReleaseFloatArrayElements(samples, data, JNI_ABORT);
        env->ReleaseStringUTFChars(lang, language);
    }
    jbyteArray result = env->NewByteArray(static_cast<jsize>(out.size()));
    env->SetByteArrayRegion(result, 0, static_cast<jsize>(out.size()),
                            reinterpret_cast<const jbyte *>(out.data()));
    return result;
}
