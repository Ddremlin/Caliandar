package com.ddremlin.kaliandar.ui

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.ddremlin.kaliandar.R
import com.ddremlin.kaliandar.data.Event
import com.ddremlin.kaliandar.data.EventColors
import com.ddremlin.kaliandar.data.ReminderOptions
import com.ddremlin.kaliandar.data.Repeat
import com.ddremlin.kaliandar.data.repeatType
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

private const val DAY_MS = 86_400_000L
private const val LAST_MINUTE = 23 * 60 + 59

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventEditor(
    initial: Event,
    onSave: (Event) -> Unit,
    onDelete: (Event) -> Unit,
    onClose: () -> Unit,
) {
    val locale = LocalConfiguration.current.locales[0]
    val context = LocalContext.current

    var title by rememberSaveable { mutableStateOf(initial.title) }
    var description by rememberSaveable { mutableStateOf(initial.description) }
    var epochDay by rememberSaveable { mutableLongStateOf(initial.date) }
    var allDay by rememberSaveable { mutableStateOf(initial.allDay) }
    var start by rememberSaveable { mutableIntStateOf(initial.startMinute) }
    var end by rememberSaveable { mutableIntStateOf(initial.endMinute) }
    var color by rememberSaveable { mutableIntStateOf(initial.color) }
    var reminder by rememberSaveable { mutableIntStateOf(initial.reminderMinutes) }
    var repeat by rememberSaveable { mutableStateOf(initial.repeatType) }

    var showDate by remember { mutableStateOf(false) }
    var pickTime by remember { mutableStateOf<Int?>(null) } // 0 = start, 1 = end
    var confirmDelete by remember { mutableStateOf(false) }

    val isNew = initial.id == 0L
    val dateFmt = remember(locale) { DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(locale) }
    val timeFmt = remember(locale) { DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(locale) }
    fun minuteText(m: Int) = LocalTime.of(m / 60, m % 60).format(timeFmt)

    fun save() {
        val fixedEnd = if (end <= start) (start + 60).coerceAtMost(LAST_MINUTE) else end
        onSave(
            initial.copy(
                title = title.trim(),
                description = description.trim(),
                date = epochDay,
                allDay = allDay,
                startMinute = start,
                endMinute = fixedEnd,
                color = color,
                reminderMinutes = reminder,
                repeat = repeat.name,
            )
        )
    }

    Dialog(onDismissRequest = onClose, properties = FullScreenDialog) {
        DialogResizesWithKeyboard()
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = onClose) {
                            Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.cancel))
                        }
                    },
                    title = { Text(stringResource(if (isNew) R.string.new_event else R.string.edit_event)) },
                    actions = {
                        if (!isNew) {
                            IconButton(onClick = { confirmDelete = true }) {
                                Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete))
                            }
                        }
                        TextButton(onClick = ::save) { Text(stringResource(R.string.save)) }
                    },
                )
            },
        ) { padding ->
            Column(
                Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .imePadding() // keyboard open -> the form can still be scrolled to the end
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(stringResource(R.string.title)) },
                    singleLine = true,
                    trailingIcon = { VoiceButton { title = appendDictation(title, it) } },
                    modifier = Modifier.fillMaxWidth(),
                )

                Labeled(stringResource(R.string.date)) {
                    OutlinedButton(onClick = { showDate = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(LocalDate.ofEpochDay(epochDay).format(dateFmt).replaceFirstChar { it.titlecase(locale) })
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.all_day), Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    Switch(checked = allDay, onCheckedChange = { allDay = it })
                }

                if (!allDay) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Labeled(stringResource(R.string.start), Modifier.weight(1f)) {
                            OutlinedButton(onClick = { pickTime = 0 }, modifier = Modifier.fillMaxWidth()) {
                                Text(minuteText(start))
                            }
                        }
                        Labeled(stringResource(R.string.end), Modifier.weight(1f)) {
                            OutlinedButton(onClick = { pickTime = 1 }, modifier = Modifier.fillMaxWidth()) {
                                Text(minuteText(end))
                            }
                        }
                    }
                }

                OptionPicker(
                    label = stringResource(R.string.reminder),
                    value = reminder,
                    options = ReminderOptions,
                    text = { reminderLabel(it) },
                    onPick = { reminder = it },
                )

                OptionPicker(
                    label = stringResource(R.string.repeat),
                    value = repeat,
                    options = Repeat.entries,
                    text = { repeatLabel(it) },
                    onPick = { repeat = it },
                )

                Labeled(stringResource(R.string.color)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EventColors.forEachIndexed { i, c ->
                            Box(
                                Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(c))
                                    .then(
                                        if (i == color) Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                        else Modifier
                                    )
                                    .clickable { color = i },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (i == color) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text(stringResource(R.string.description)) },
                    minLines = 3,
                    trailingIcon = { VoiceButton { description = appendDictation(description, it) } },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.size(24.dp))
            }
        }
    }

    if (showDate) {
        val state = rememberDatePickerState(initialSelectedDateMillis = epochDay * DAY_MS)
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { epochDay = Math.floorDiv(it, DAY_MS) }
                    showDate = false
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = {
                TextButton(onClick = { showDate = false }) { Text(stringResource(R.string.cancel)) }
            },
        ) {
            DatePicker(state = state)
        }
    }

    pickTime?.let { which ->
        val initialMinute = if (which == 0) start else end
        val state = rememberTimePickerState(
            initialHour = initialMinute / 60,
            initialMinute = initialMinute % 60,
            is24Hour = DateFormat.is24HourFormat(context),
        )
        AlertDialog(
            onDismissRequest = { pickTime = null },
            confirmButton = {
                TextButton(onClick = {
                    val value = state.hour * 60 + state.minute
                    if (which == 0) {
                        // Keep the event duration when the start time moves
                        val duration = (end - start).coerceAtLeast(15)
                        start = value
                        end = (value + duration).coerceAtMost(LAST_MINUTE)
                    } else {
                        end = value
                    }
                    pickTime = null
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = {
                TextButton(onClick = { pickTime = null }) { Text(stringResource(R.string.cancel)) }
            },
            text = { TimePicker(state = state) },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            text = { Text(stringResource(R.string.delete_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(initial)
                }) { Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun Labeled(label: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(modifier) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 4.dp),
        )
        content()
    }
}

@Composable
private fun <T> OptionPicker(
    label: String,
    value: T,
    options: List<T>,
    text: @Composable (T) -> String,
    onPick: (T) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    Labeled(label) {
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text(text(value), Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Filled.KeyboardArrowDown, null)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(text(option)) },
                        onClick = {
                            onPick(option)
                            open = false
                        },
                    )
                }
            }
        }
    }
}

@Composable
fun reminderLabel(minutes: Int): String = when (minutes) {
    -1 -> stringResource(R.string.reminder_none)
    0 -> stringResource(R.string.reminder_at_time)
    5 -> stringResource(R.string.reminder_5)
    15 -> stringResource(R.string.reminder_15)
    30 -> stringResource(R.string.reminder_30)
    60 -> stringResource(R.string.reminder_60)
    1440 -> stringResource(R.string.reminder_1day)
    else -> "$minutes min"
}

@Composable
fun repeatLabel(repeat: Repeat): String = when (repeat) {
    Repeat.NONE -> stringResource(R.string.repeat_none)
    Repeat.DAILY -> stringResource(R.string.repeat_daily)
    Repeat.WEEKLY -> stringResource(R.string.repeat_weekly)
    Repeat.MONTHLY -> stringResource(R.string.repeat_monthly)
    Repeat.YEARLY -> stringResource(R.string.repeat_yearly)
}
