package com.ddremlin.kaliandar.ui

import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider

/** Full-screen dialog that lets Compose handle the keyboard (content is padded and scrollable). */
val FullScreenDialog = DialogProperties(
    usePlatformDefaultWidth = false,
    decorFitsSystemWindows = false,
)

/**
 * Call inside a Dialog: the window shrinks when the keyboard opens
 * (needed on Android 10 and older, where IME insets are not delivered otherwise).
 */
@Composable
fun DialogResizesWithKeyboard() {
    val view = LocalView.current
    SideEffect {
        (view.parent as? DialogWindowProvider)?.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
    }
}
